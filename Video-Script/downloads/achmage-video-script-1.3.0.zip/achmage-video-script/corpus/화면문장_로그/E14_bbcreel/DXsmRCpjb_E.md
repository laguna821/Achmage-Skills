# Inside a Chinese sex doll factory - BBC REEL

- 채널/시리즈: BBC Reel (현 채널명 BBC Global), 장소 단편. 엔딩 로고는 "THE SMART GUIDE TO WORK AND LIFE"(BBC의 다른 섹션 브랜드로 보임)
- URL: https://www.youtube.com/watch?v=DXsmRCpjb_E
- 길이: 3분 13초
- 게시일 / 조회수: 2018-09-27 / 1,120,869
- 음성 유형: 인터뷰 중심(3인 + 인형 음성), 내레이션 없음. 근거: 유튜브 자막 트랙은 없지만, 화면 하단 번역 자막이 공장 관계자들의 발언("Follow me.", "My family didn't support me in the beginning.")으로 이어진다. 편집자가 쓴 문장은 음성이 아닌 화면 카드로 세 번만 나온다(경고문, 제목, 통계 카드 묶음). 실제 음향은 확인하지 못했다.
- 자료: 콘택트시트 7장 (표본 간격 2.5초), 자막 트랙 없음

## 화면 문장 로그

글자 층은 세 가지다. (가) 편집 카드: 큰 흰 글씨, 좌우에 가는 세로선, 화면 왼쪽 위 또는 가운데. (나) 이름 자막: 좌상단, 이름 / 직함 2줄. (다) 번역 자막: 하단 가운데, 작은 흰 글씨 1~2줄.

| 시각 | 화면 문장 (원문) | 장면 | 구분 |
|---|---|---|---|
| 00:00 | This video contains sexual content. | 검은 화면 | 표기(시청 경고) |
| 00:05 | (문장 없음: 장면만 약 5초) | 인형 얼굴의 눈 클로즈업 | |
| 00:10 | **Your virtual girlfriend** / China's booming sex toy industry | 공장 내부, 인형을 들고 걸어가는 작업자 | 제목 |
| 00:15 | Follow me. | 문 앞에 선 여성 관리자 | 인용 |
| 00:18 | Jing Chen / Deputy general manager | 좌상단 이름 자막 | 표기 |
| 00:18 | Our dolls are like human beings. | 관리자 | 인용 |
| 00:20 | It also has a skeleton, muscle and skin. | 관리자 | 인용 |
| 00:23 | The skeleton consists of over 160 parts. | 금속 골격을 든 작업자, 부품 선반 앞 작업자 | 인용 |
| 00:30 | This is where the skeleton / gets its foam muscle. | 작업장으로 걸어 들어가는 관리자 | 인용 |
| 00:35 | (문장 없음: 장면만 약 7초) | 성형 틀에서 몸체를 꺼내는 작업자들 | |
| 00:43 | The foam body needs to fix in this mould. | 몸체 틀 앞에서 설명하는 관리자 | 인용 |
| 00:50 | This procedure needs precision. | 골격을 맞추는 젊은 작업자 클로즈업 | 인용 |
| 00:53 | There is no room for error. | 같은 작업자 | 인용 |
| 00:58 | (문장 없음) | 작업장 전경 | |
| 01:00 | Dongyue Yang / Board chairman and general manager | 좌상단 이름 자막, 회사 로고 벽 앞 인터뷰 컷 | 표기 |
| 01:00 | My family didn't support me in the beginning. | 인터뷰 컷 | 인용 |
| 01:03 | They thought Chinese / would not buy this product. | 인터뷰 컷 | 인용 |
| 01:08 | They argued that | 인형을 옮기는 작업자 | 인용 |
| 01:10 | the rich don't need them / while the poor can't afford them. | 유리벽 너머 작업장 | 인용 |
| 01:13 | (문장 없음: 장면만 약 7초) | 매달린 몸체들 사이의 작업자 | |
| 01:20 | People are eloquent about food. | 인터뷰 컷 | 인용 |
| 01:25 | They share their preferences. | 몸체 표면을 손질하는 작업자 | 인용 |
| 01:28 | But when talking about sex [이하 누락 가능] | 같은 장면 | 인용 |
| 01:30 | (문장 없음: 장면만 약 5초, 자막 누락 가능) | 방호복과 방독면을 쓴 작업자가 분사기로 채색 | |
| 01:35 | Attitudes towards sex have / changed a lot in the last 20 years. | 분사기를 든 손 | 인용 |
| 01:38 | Young people think sex / is a beautiful thing. | 방호복 작업자 | 인용 |
| 01:40 | A pleasant thing. | 유리벽 너머 채색실 | 인용 |
| 01:43 | China's first sex shop opened in 1993. / Now there are more than 200,000 sex / shops in China. | 유리벽 너머 채색실 위의 큰 글씨 카드 | 편집 |
| 01:48 | It's a booming industry. | 같은 화면, 앞 카드 아래에 추가 | 편집 |
| 01:53 | The online market for sex toys is worth / 18.9bn yuan ($2.9bn). And it's forecasted to / be worth $9.1bn by 2020. | 같은 화면, 앞 카드가 사라지고 새 카드 | 편집 |
| 01:58 | (문장 없음) | 몸체를 다듬는 작업자 뒷모습 | |
| 02:00 | We want to give our dolls personalities. | 표면을 문지르는 손 클로즈업 | 인용 |
| 02:03 | This is Daisy. | 선반의 얼굴 모형들을 꺼내 보이는 작업자 | 인용 |
| 02:05 | This is Samantha. | 같은 장면 | 인용 |
| 02:10 | Now we're trying to make our dolls move. | 모니터의 3차원 인체 모형, 이어 눈과 입이 움직이는 인형 얼굴 | 인용 |
| 02:15 | Make them speak. And talk to you. | 말하듯 입을 여는 인형 얼굴 | 인용 |
| 02:18 | Hi dear. | 단발 인형의 옆얼굴 | 인용(사람이 인형에게 건네는 말로 보임) |
| 02:20 | Do you know who Trump is? | 같은 장면 | 인용(인형에게 묻는 말) |
| 02:23 | Donald Trump was born on June 14, 1946 in / New York City. | 같은 장면 | 인용(인형의 음성 답변으로 보임) |
| 02:30 | Yu Zhang / Research & development director | 좌상단 이름 자막, 흰 가운을 입은 남자와 인형 | 표기 |
| 02:30 | This doll can't make any expressions so far. | 같은 장면 | 인용 |
| 02:33 | It's only a voice-user interface. | 같은 장면 | 인용 |
| 02:35 | We're combining the moving ones / with this one. | 로봇 골격 얼굴과 인형들, 이어 표정이 움직이는 인형 | 인용 |
| 02:40 | Then, it will better communicate with users. | 인형 얼굴 클로즈업 | 인용 |
| 02:45 | It must look like a human being / as much as possible. | 줄지어 세워 둔 몸체들 앞에서 작업하는 사람 | 인용 |
| 02:50 | If it looks ugly, I will not talk with it / although it's smart. | 인형 얼굴에 화장을 입히는 손 | 인용 |
| 02:55 | But if it looks good, I'm willing to talk to it / although it's a little dumb. | 작업대의 사람들, 이어 완성된 인형 얼굴 | 인용 |
| 03:00 | Yes, it can replace a girlfriend or wife. | 회장 인터뷰 컷 | 인용 |
| 03:03 | (문장 없음: 장면만 약 5초) | 말없이 웃는 회장 | |
| 03:08 | Right? | 웃으며 카메라 쪽을 보는 회장 | 인용 |
| 03:10 | THE SMART / GUIDE / TO **WORK** / AND **LIFE** | 청록 바탕 로고 | 제목(엔딩 카드) |

(누락 가능: 01:28 "But when talking about sex" 뒤 문장은 표본에 잡히지 않았다. 03:00 발언은 "Yes,"로 시작하므로 취재진의 질문이 앞에 있었을 것이나 자막으로는 나오지 않았다.)

## 구조 메모

- 로그라인(이 영상이 하는 말 한 문장): 사람을 닮게 만드는 공장을 한 바퀴 돌고 나면, 만드는 사람이 "여자친구나 아내를 대신할 수 있다"고 말한다.
- 훅(첫 15~30초가 하는 일): 경고문(약 4초) 뒤에 인형의 눈 클로즈업을 5초 동안 문장 없이 보여 준다. 사람인지 아닌지 헷갈리는 그림이 훅이다. 10초에 제목이 뜬다. 주제목 "Your virtual girlfriend"는 시청자에게 말을 거는 2인칭 소유격이고, 부제 "China's booming sex toy industry"가 실제 주제(산업)를 밝힌다. 15초에 관리자의 "Follow me."로 견학이 시작된다. 인터뷰이의 말 한마디를 영상의 진행 신호로 쓴다.
- 비트 구성
	- 00:00-00:10 경고문, 눈 클로즈업
	- 00:10-00:15 제목
	- 00:15-01:00 견학 1: 어떻게 만드는가 (뼈대 160개 부품 → 발포 근육 → 틀 → 정밀함)
	- 01:00-01:42 창업자의 말: 가족의 반대와 그 논리 → 음식은 말해도 성은 말하지 않는다 → 20년 사이 태도가 바뀌었다
	- 01:42-01:58 편집 카드 묶음: 1993년 첫 가게, 지금 20만 곳, 온라인 시장 규모와 전망
	- 01:58-02:45 견학 2: 어디로 가는가 (이름 붙은 얼굴 → 움직임 → 음성 대화 시연 → 결합 계획)
	- 02:45-03:00 설계 철학: 최대한 사람처럼, 못생기면 똑똑해도 말 안 건다
	- 03:00-03:13 결말: "replace a girlfriend or wife", 웃음, "Right?"
- 전환점: 01:43의 편집 카드. 한 공장의 견학담이 '산업'으로 넓어지는 유일한 지점이고, 편집자가 직접 말하는 유일한 대목이다. 장치는 수치 대조(1993년 한 곳 → 20만 곳)와 전망 수치(2.9bn → 9.1bn)다. 이 카드는 창업자의 "Attitudes towards sex have changed a lot in the last 20 years."를 곧바로 숫자로 받는다. 인용이 주장을 하고, 카드가 근거를 댄다. 두 번째 전환은 02:10 "Now we're trying to make our dolls move."로, 제조 이야기가 '대화 상대' 이야기로 넘어간다.
- 결말(마지막 2~3개 카드와 그 기능): "If it looks ugly, I will not talk with it although it's smart." / "But if it looks good, I'm willing to talk to it although it's a little dumb." → "Yes, it can replace a girlfriend or wife." → (5초간 웃음) → "Right?" 제목 "Your virtual girlfriend"가 던진 물음에 당사자가 답하게 하고, 그 답에 붙은 되묻는 말 한마디로 끊는다. 편집자는 동의도 반박도 하지 않고, 웃는 얼굴을 5초 남겨 판단을 시청자에게 넘긴다. 인용 + 질문형 결말이다.
- 문장 작법
	- 편집 문장은 세 군데뿐이다: 경고문 1장(5단어), 제목(주제목 3단어 + 부제 5단어), 통계 카드 3장(16단어, 4단어, 21단어).
	- 통계 카드는 인터뷰 자막보다 훨씬 큰 글씨로, 화면 왼쪽 위에 세로선과 함께 놓는다. 문장은 완결된 평서문이고 현재 시제다. 과거 한 점과 현재를 맞세운다("opened in 1993. Now there are more than 200,000"). 가운데에 판정 한 줄("It's a booming industry.")을 끼워 부제의 낱말(booming)을 되풀이한다. 통화는 위안과 달러를 병기한다.
	- 번역 자막은 3~14단어로 짧다. 한 자막에 한 문장. 견학 구간은 지시어로 시작한다("This is where ...", "This is Daisy.", "This doll ..."). 화면을 가리키는 말이라 그림 없이는 뜻이 서지 않는다.
	- 대구가 있는 발언을 골라 썼다: "the rich don't need them while the poor can't afford them.", "If it looks ugly ... although it's smart. / But if it looks good ... although it's a little dumb."
	- 이름 자막은 이름 / 직함 2줄, 인물마다 첫 등장에 한 번.
	- 강조 표시는 없다. 층 구분은 글자 크기와 위치로만 한다.
- 화면과 문장의 분업: 공정은 화면이 보여 주고, 자막은 화면에 안 보이는 수치와 이유만 댄다(160개 부품, 정밀함). 창업자의 긴 발언 사이에는 공장 장면을 5~7초씩 문장 없이 끼워 넣는다. 편집 카드는 인터뷰 얼굴이 아니라 작업장 원경 위에 얹는다. 시작(눈 클로즈업)과 끝(웃는 얼굴)에 문장 없는 5초를 둔다. 둘 다 '얼굴'이고, 하나는 인형, 하나는 사람이다.
- 수량(대략): 편집 문장 카드 3장(통계) + 제목 1 + 경고 1, 약 55단어. 이름 자막 3건. 인용 자막 약 36개, 약 250단어. 자막당 평균 7단어, 노출 약 2.5~5초. 통계 카드 묶음의 노출은 약 15초. 문장 없는 구간이 합쳐 약 40초(전체의 5분의 1)다.
