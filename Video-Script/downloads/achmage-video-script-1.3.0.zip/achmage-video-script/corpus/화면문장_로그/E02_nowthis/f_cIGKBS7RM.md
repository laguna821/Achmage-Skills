# Lion Reunites With His 'Human' Mother | NowThis

- 채널/시리즈: NowThis (정사각형 소셜 피드용 화면 문장형 뉴스. 2020년의 완성형 템플릿)
- URL: https://www.youtube.com/watch?v=f_cIGKBS7RM
- 길이: 3분 4초 (본편 약 3분, 마지막 3초는 로고와 제작진 크레딧)
- 게시일 / 조회수: 2020-03-02 / 8,520,904
- 음성 유형: 무내레이션 + 현장음·발언. 근거: 유튜브 자막 트랙 없음. 01:13-01:20과 02:35-02:55에 기자 마이크 앞에서 말하는 인물 화면과 이탤릭 번역 자막이 있어 현지어 발언 음성이 있는 것으로 판단. 서술은 전부 화면 문장이 맡고 내레이터는 없다. 음악 유무는 프레임만으로 확인 불가.
- 자료: 콘택트시트 7장 (표본 간격 2.5초), 자막 트랙 없음

## 화면 문장 로그

| 시각 | 화면 문장 (원문) | 장면 | 구분 |
|---|---|---|---|
| 00:00-00:03 | (문장 없음: 장면만 약 4초) | 붉은 철창 사이로 사자가 앞발을 내밀어 여성을 끌어안음 | - |
| 00:05-00:08 | **A lion has been** / **reunited** with his / human 'mother' (아래 노란 밑줄) | 철창 사이로 얼굴을 맞댄 여성과 사자 | 편집 |
| 00:10 | in an / attempt to save his / **deteriorating health** (아래 노란 밑줄) | 갈비뼈가 드러난 채 누운 사자 | 편집 |
| 00:13-00:15 | CALI, COLOMBIA (좌상단 위치 핀 라벨) | 여성이 사자를 쓰다듬음 | 표기 |
| 00:18 | (문장 없음) | 철창 너머로 팔을 뻗는 여성 | - |
| 00:20 | **Jupiter the lion** / was rescued from the / circus as a newborn | 풀숲에 앉은 사자 | 편집 |
| 00:23-00:25 | after his mother, / **who had been abused,** / gave birth | 사자 얼굴 클로즈업 | 편집 |
| 00:28 | He was sent to a / Colombian rescue / **for abused animals,** | 천으로 덮인 우리에 얼굴을 대는 여성(분홍 모자) | 편집 |
| 00:30-00:33 | where he befriended the / founder, **Ana Julia Torres** | 같은 장면 | 편집 |
| 00:35 | (문장 없음) | 같은 장면 | - |
| 00:38-00:40 | Videos of them / embracing **repeatedly** / **have gone viral** | 사자와 입을 맞추는 여성 | 편집 |
| 00:43-00:45 | **as their unlikely** / **bond** touches the hearts / of people online | 같은 장면 | 편집 |
| 00:48-00:50 | **But in 2017, environmental** / **agencies** announced they / would remove | 철망 우리 전경 | 편집 |
| 00:53-00:55 | **almost 200 animals** / from Torres' shelter | 철망 너머 초록빛 속 사자의 눈 | 편집 |
| 00:58-01:00 | Local reports say / the agencies didn't / think Torres had | 입 맞추는 장면 | 편집 |
| 01:03-01:05 | **the proper resources or** / **documentation** to care for / many of the animals | 같은 장면 | 편집 |
| 01:08-01:10 | And in 2019, Jupiter / **was relocated** to the / Los Caimanes Zoo | 흙바닥에 누운 여윈 사자 | 편집 |
| 01:13 | It's terrible. It's like a 19-year-old / son was taken away from me. / (이름표) Ana Julia Torres / FOUNDER, VILLA LORENA ANIMAL RESCUE | 방송 마이크 앞에서 말하는 여성 | 인용 + 표기 |
| 01:15-01:18 | I had seen him grow as a child, / as a young lion, to adulthood | 같은 인터뷰 | 인용 |
| 01:20 | and then to be separated / when he turned 19. | 같은 인터뷰 | 인용 |
| 01:23-01:25 | On February 20, Torres / reportedly visited Jupiter / **at his new home,** | 흙바닥에 웅크린 사자와 곁에 선 사람 | 편집 |
| 01:28-01:30 | only to find he had lost / **hundreds of pounds** | 뼈만 남은 사자 | 편집 |
| 01:33-01:35 | Torres told reporters / that she **didn't recognize** / the lion | 누운 사자 얼굴 | 편집 |
| 01:38-01:40 | and that Jupiter's / condition has led to / **liver & kidney damage** | 사자를 돌보는 사람 | 편집 |
| 01:43-01:45 | The public joined in / Torres' worry after a / video circulated | 갈비뼈가 드러난 사자 | 편집 |
| 01:48-01:50 | of Jupiter looking / malnourished & / despondent | 같은 장면 | 편집 |
| 01:53-01:55 | The Colombian minister / of defense announced | 꽃 장식이 달린 우리 안의 사자 | 편집 |
| 01:58-02:00 | Jupiter would be moved / **back to Cali,** near Torres | 군용기 앞, 트럭에 실린 덮개 씌운 우리 | 편집 |
| 02:03-02:20 | (문장 없음: 장면만 약 18초) | 우리를 수송기에 싣는 사람들, 활주로를 달려 이륙하는 수송기 | - |
| 02:23-02:25 | On February 27, the / **20-year-old lion** was / transferred back to Cali | 사자 사진이 실린 환영 팻말을 든 남자와 소년 | 편집 |
| 02:28 | (문장 없음) | 팻말 속 사자 사진 | - |
| 02:30-02:33 | The city is working to / bring back his health | 사자를 치료하는 사람들 | 편집 |
| 02:35 | We will do everything / possible for his recovery | 마이크에 둘러싸인 남성 | 인용 |
| 02:38 | in the correct way, given / the levels of malnutrition / (이름표) Jorge Iván Ospina / MAYOR, CALI | 같은 인터뷰 | 인용 + 표기 |
| 02:40 | and anemia that he has. | 같은 인터뷰 | 인용 |
| 02:43-02:45 | What we are doing today for this / king of the jungle | 같은 인터뷰 | 인용 |
| 02:48-02:50 | is to say that all sentient lives / should be protected | 같은 인터뷰 | 인용 |
| 02:53-02:55 | and looked after, especially a wild / animal that shouldn't be caged. | 같은 인터뷰 | 인용 |
| 02:58-03:00 | (문장 없음) | 첫 장면 반복: 철창 사이로 끌어안는 여성과 사자 | - |
| 03:03 | NOW THIS / PRODUCER MADELEINE PTACIN / SCRIPT EDITOR MIKE MADDEN / SENIOR PRODUCER TOM MCKENNA | 같은 장면 위에 로고와 크레딧 | 제목 |

강조 표시: 굵게 표시한 부분은 화면에서 노란색, 나머지는 흰색. 편집 문장은 굵은 고딕, 좌하단 왼쪽 정렬 3줄. 발언 자막은 가는 이탤릭, 하단 가운데 정렬 2줄, 강조색 없음. 영상 출처(Reuters, El Tiempo, NPR, AFP / Stringer, Top 10 News, Personería de Cali, Twitter / @DAGMA)는 오른쪽 가장자리에 세로로 작게 표기. 우상단에 NOW THIS 로고 상시 노출.

## 구조 메모

- 로그라인(이 영상이 하는 말 한 문장): 서커스에서 구조돼 20년 가까이 한 여성과 지낸 사자 주피터가 당국에 의해 옮겨진 뒤 쇠약해졌고, 여론과 정부 결정으로 그녀 곁에 돌아왔다.
- 훅(첫 15~30초가 하는 일): 가장 강한 그림(사자가 철창 사이로 사람을 끌어안는 장면)을 문장 없이 4초 보여 준 다음, 결과부터 말하는 뉴스 리드 한 문장을 두 카드로 낸다("A lion has been reunited with his human 'mother'" / "in an attempt to save his deteriorating health"). 첫 카드는 따뜻한 사실, 둘째 카드는 불안한 조건이고, 둘째 카드에서 화면이 여윈 사자로 바뀐다. 10초 만에 "재회했다, 그런데 왜 아팠나"라는 질문이 생긴다.
- 비트 구성:
	- 00:00-00:10 장면 훅 + 리드 문장 (결과 먼저)
	- 00:13-00:18 장소 표기, 문장 없는 호흡
	- 00:20-00:33 기원: 서커스에서 구조 → 보호소 → 설립자와의 만남 (이름 공개)
	- 00:38-00:45 유명해진 이유: 포옹 영상의 확산
	- 00:48-01:10 갈등: "But in 2017" 당국의 동물 이전 발표, 이유, 2019년 동물원 이송
	- 01:13-01:20 당사자 발언 (상실감: "19-year-old son")
	- 01:23-01:50 위기: 2월 20일 방문, 체중 감소, 장기 손상, 영상 확산과 여론
	- 01:53-02:00 해결의 결정: 국방장관의 발표
	- 02:03-02:20 문장 없는 이송 장면 (약 18초)
	- 02:23-02:33 결과: 2월 27일 칼리 복귀, 시의 치료
	- 02:35-02:55 시장 발언 (약속과 원칙)
	- 02:58-03:03 첫 장면 반복, 로고와 크레딧
- 전환점(시청자의 해석이 바뀌는 지점과 그것을 일으킨 장치): 00:48 "But in 2017"(역접 접속사 + 연도). 훈훈한 유대 이야기가 행정 조치로 인한 이별로 꺾인다. 두 번째는 01:28 "only to find he had lost hundreds of pounds"(기대와 결과의 대조 구문 + 여윈 사자의 그림). 세 번째는 01:53 장관의 발표로 회복 쪽으로 다시 돈다. 전부 시간 표지(But in 2017 / And in 2019 / On February 20 / On February 27)가 꺾임을 알린다.
- 결말(마지막 2~3개 카드와 그 기능): 편집 문장의 마지막은 "The city is working to bring back his health"(미완의 현재형)이고, 그 뒤 시장의 발언이 가치 명제를 대신 말한다("all sentient lives should be protected... a wild animal that shouldn't be caged."). 마지막 그림은 오프닝의 포옹 장면으로 돌아간다. 유형은 인용 + 수미상관(영상). 편집자는 평가를 직접 쓰지 않는다.
- 문장 작법:
	- 한 카드 2~3줄, 5~11단어(평균 약 8.5단어). 줄당 3~4단어.
	- 한 문장을 두 카드로 나누는 것이 기본 단위다. 23장의 카드가 13개 문장을 이룬다. 자르는 자리는 전치사구, 관계절, that절, 목적어 앞이다("...announced they would remove" / "almost 200 animals from Torres' shelter").
	- 카드 끝에 마침표를 찍지 않는다. 쉼표는 다음 카드로 이어진다는 표시로 남긴다("for abused animals," → "where he befriended...").
	- 시제: 리드는 현재완료(has been reunited), 배경은 과거, 현재 상황은 현재진행(is working).
	- 출처 한정: "Local reports say", "reportedly", "Torres told reporters that"으로 확인 수준을 문장 안에 넣는다.
	- 강조: 카드당 노란색 1덩어리(2~4단어). 주어·이름(A lion has been reunited, Jupiter the lion, Ana Julia Torres), 꺾임(But in 2017, environmental agencies), 수치·상태(almost 200 animals, hundreds of pounds, liver & kidney damage), 결과(back to Cali). 강조가 없는 카드도 6장쯤 있다(연결 구실만 하는 카드).
	- 수치: 2017, 2019, almost 200, 19, February 20, hundreds of pounds, February 27, 20-year-old. 날짜가 서사의 마디가 된다.
	- 인용: 가는 이탤릭 2줄, 가운데 정렬. 이름표는 흰 상자(이름 이탤릭 + 직함 대문자). 발언 중에는 편집 문장을 띄우지 않는다.
- 화면과 문장의 분업: 장면은 관계의 온도(포옹, 입맞춤)와 몸의 변화(풍성한 갈기 → 드러난 갈비뼈)를 맡는다. 같은 포옹 영상이 여러 번 재사용되는데, 문장이 바뀌면서 그 의미가 달라진다(행복 → 상실 → 회복). 문장은 연도, 기관, 이유, 수치, 결정 주체를 맡는다. 가장 긴 무문장 구간(02:03-02:20, 18초)은 수송기 이송 장면으로, 해결 직전의 기대를 끄는 데 쓰인다.
- 수량(대략): 편집 문장 카드 23장(문장 13개), 총 약 195단어, 카드당 평균 약 8.5단어, 카드 평균 노출 약 4~5초. 인용 자막 9개(여성 3, 시장 6). 표기: 장소 1, 이름표 2, 출처 다수. 문장 없는 구간 합계 약 35초.
