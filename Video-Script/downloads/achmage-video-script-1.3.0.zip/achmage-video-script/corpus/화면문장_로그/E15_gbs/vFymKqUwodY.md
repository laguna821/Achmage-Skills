# Building a Prosthetic Arm With Lego

- 채널/시리즈: Great Big Story
- URL: https://www.youtube.com/watch?v=vFymKqUwodY
- 길이: 2분 41초
- 게시일 / 조회수: 2018-03-12 / 34,765,790
- 음성 유형: 내레이션 있음(3인칭 내레이터) + 당사자 발언(추정). 제작자 영어 자막(manual, en) 133단어가 전부 "[Narrator]" 표시가 붙은 3인칭 문장이다("Meet David Aguilar.", "He likes EDM."). 자막이 있는 시간은 다 합쳐 45초 남짓이고, 사이사이에 9~18초의 공백이 있으며 01:40 이후 마지막 1분은 자막이 없다. 공백 구간에는 당사자(David)의 영어가 아닌 발언이 화면 자막과 함께 나왔을 가능성이 높으나, 주어진 자료로는 확인하지 못했다.
- 자료: 자막 트랙만 있음(manual/en, 133단어). 콘택트시트 없음. 화면 구성과 화면 문장은 확인하지 못했다.

## 대본 구조 메모

- 로그라인(이 영상이 하는 말 한 문장): 오른팔이 덜 자란 채 태어난 David Aguilar가 좋아하던 레고로 자기 의수를 만들었다(자막에서 확인되는 범위).
- 훅(첫 15~30초가 하는 일): 처음 13초는 말이 없다. 14초에 내레이터의 세 단어 "Meet David Aguilar."가 나오고, 20초에 조건 한 문장 "When David was born, his right arm hadn't fully developed."가 온다. 이름을 부르며 인사시키는 형식이다. 그 뒤 13초가 다시 비어 있다.
- 비트 구성(자막 기준, 공백 포함):
	- 00:00-00:13 말 없음
	- 00:14-00:21 소개와 조건
	- 00:22-00:34 공백 약 13초
	- 00:35-00:55 "보통 아이"의 목록: EDM을 좋아한다 / 별명은 Hand Solo("Get it?") / 창피한 아빠가 있다 / 학교에 간다 / 레고 팔로 문을 연다("So cool.")
	- 00:56-01:00 집착의 기원: 어릴 때부터 레고에 빠짐, 그것을 "literally" 자기 일부로 만들고 싶었다
	- 01:00-01:08 공백 약 8초
	- 01:09-01:15 첫 실패와 시간 점프: 블록이 약했고 9년 뒤에야 다시 시도
	- 01:15-01:32 공백 약 18초
	- 01:33-01:40 첫 모델 MK1은 닷새 만에, 곧바로 개량에 착수
	- 01:40-02:41 영어 자막 없음(약 60초)
- 전환점(시청자의 해석이 바뀌는 지점과 그것을 일으킨 장치): 00:35 "And while some would see this as a disadvantage, David is just a regular kid." 장애 이야기로 들어갈 것 같은 기대를 한 문장으로 꺾는다. 뒤따르는 목록이 평범한 항목 넷 뒤에 비범한 항목 하나를 같은 문형으로 끼워 넣는다("He goes to school. / And, he can open doors with his Lego arm."). 평범함의 나열 속에 놓아 특별함을 과장 없이 드러내는 장치다.
- 결말(마지막 2~3개 문장과 그 기능): 자막상 마지막 문장은 01:33의 "That model, the MK1, only took five days to build, of course, like any good inventor, he got straight to work on an upgrade."이고 그 뒤 1분은 자막이 없다. 실제 결말은 확인하지 못했다.
- 내레이터와 당사자의 분업(같은 채널의 당사자 음성형과 견주어):
	- 이 영상은 표본 가운데 유일하게 내레이터가 있다. 당사자가 영어로 말하지 않을 때 채널이 택한 방식으로 보인다(추정).
	- 내레이터는 길게 말하지 않는다. 한 번 나올 때 1~3문장만 하고 물러난다. 맡은 일은 소개(Meet ...), 조건, 인물 스케치, 시간 점프("it wasn't for another nine years"), 다음 구간 예고(upgrade)다. 곧 다리 놓기만 한다.
	- 내레이터 문장 다음에는 번번이 긴 공백이 온다. 내레이터가 화제를 열고 당사자나 장면이 내용을 채우는 구조로 읽힌다.
- 내레이터 문장 작법:
	- 문장 평균 약 9.5단어. "He + 동사" 단문 연타("He likes EDM. / He goes by the name, Hand Solo. / He has an embarrassing dad. / He goes to school.").
	- 시청자에게 말을 거는 추임새: "Get it?", "So cool." 다큐 해설자가 아니라 친구를 소개하는 사람의 말투다.
	- 수치는 시간 단위 두 개뿐: another nine years, five days.
	- 부사 하나로 농담을 만든다: "make it a part of him, literally."
- 화면과 말의 분업: 화면은 확인하지 못했다.
- 수량(대략): 내레이터 133단어, 문장 14개, 발화 시간 합계 약 45초(전체 161초의 약 28%).
- 주의: 이 메모는 영어 자막 트랙만 반영한다. 당사자의 말과 영상의 후반부(01:40 이후)는 분석하지 못했다.
