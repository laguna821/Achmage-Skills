# ESOcast 212 Light: First Giant Planet around White Dwarf Found

- 채널/시리즈: European Southern Observatory (ESO) / ESOcast Light
- URL: https://www.youtube.com/watch?v=5hEbWWdZayY
- 길이: 1분 22초
- 게시일 / 조회수: 2019-12-04 / 90,925
- 음성 유형: 무내레이션(음악만으로 추정). 근거: 제작자 영어 자막 트랙의 본문 7개 큐가 화면 문장 7개와 같고, 화면 태그라인과 기관 표어("bite-sized astronomy", "Reaching new heights in Astronomy. Produced by ESO...")까지 자막 트랙에 들어 있어 자막이 화면 글자의 전사임이 분명하다. 크레딧에 음악(STAN DART, Rings of Beauty)만 있고 내레이터 표기가 없다. 소리 자체는 듣지 못했다.
- 자료: 콘택트시트 4장 (표본 간격 2초), 자막 트랙 있음 (manual/en, 148 words)

## 화면 문장 로그

| 시각 | 화면 문장 (원문) | 장면 | 구분 |
|---|---|---|---|
| 00:02-00:06 | (문장 없음: 시리즈 인트로 6초. 로고 ESOCAST LIGHT) | 원형 HUD 그래픽과 망원경 사진 타일 | 제목 |
| 00:08 | **First Giant Planet around / White Dwarf Found** | 검은 화면, 파란 띠 위 흰 글씨 | 제목 |
| 00:12 | (문장 없음) | 해 질 녘 VLT 망원경 건물들, 별하늘 | |
| 00:14-00:18 | ESO's **Very Large Telescope** has found / evidence of a **giant planet** around a / **white dwarf star**. | 같은 VLT 전경 | 편집 |
| 00:20 | (문장 없음) | 은하수 별밭 | |
| 00:22-00:28 | Astronomers had surveyed around **7000 white / dwarfs** and found one **unlike any other,** with / chemical elements in amounts never before / seen at a white dwarf. | 별밭 위를 천천히 이동 | 편집 |
| 00:30 | (문장 없음) | 별밭 | |
| 00:32-00:38 | Detailed observations with the **X-shooter** / instrument on the VLT confirmed the presence / of **hydrogen, oxygen and sulphur**... | 푸른 중심별을 감싼 주황색 소용돌이 원반 (상상도, 근접) | 편집 |
| 00:40-00:44 | ...and found that these elements were in a / **disc of gas swirling into the white dwarf.** | 같은 원반 | 편집 |
| 00:46-00:52 | These clues point to the existence of a / **Neptune-like exoplanet orbiting the / white dwarf**. | 물러난 시점. 원반 바깥에서 꼬리를 끄는 작은 행성이 화면 안으로 들어옴 | 편집 |
| 00:54-00:58 | The radiation from the hot white dwarf / **evaporates the planet's atmosphere**, / forming the disc of gas. | 행성에서 가스 꼬리가 원반으로 흘러듦 | 편집 |
| 01:00 | (문장 없음) | 거대한 태양 앞의 지구형 행성 | |
| 01:02-01:06 | This unique system hints at what our / **own Solar System** might look like in / the **distant future**. | 부풀어 오른 태양 앞에서 행성이 붉게 달아오름 | 편집 |
| 01:08 | (문장 없음) | 같은 장면, 문장 사라짐 | |
| 01:10 | bite-sized astronomy | 파란 전면 카드 | 제목 |
| 01:12-01:16 | Produced by ESO, / the European Southern Observatory. / Reaching new heights / in Astronomy | ESO 로고, 검은 화면 | 제목 |
| 01:18-01:20 | Music: STAN DART (www.stan-dart.com) - Rings of Beauty. / Footage and photos: ESO, L. Calçada, M. Kornmesser, / Space Engine (spaceengine.org), C. Malin (christophmalin.com), / and ESA/Hubble (M. Kornmesser & L. L. Christensen). / Scientific consultants: Paola Amico and Mariya Lyubenova. | 검은 화면 크레딧 (첫 줄은 "ESO."만 보이고 그 앞은 표본에서 잘림) | 표기 |

화면 문장과 자막 트랙 대조: 본문 7장이 자막 트랙과 문장, 순서, 말줄임표 위치까지 같다. 화면에만 있는 것은 파란 강조 띠와 크레딧, 자막 트랙에만 있는 것은 "Transcription by ESO; translation by" 한 줄이다.

## 구조 메모

- 로그라인: 백색왜성 7000개 가운데 하나에서 이상한 원소 조성이 나왔고, 그 원인은 별빛에 대기가 증발하는 해왕성급 행성이며, 이는 먼 미래 태양계의 모습일 수 있다.
- 훅: 제목과 첫 문장이 결론(백색왜성 둘레 거대 행성의 증거를 찾았다)을 먼저 준다. 단, "evidence of"라는 단어가 이후 문장들을 증거 제시로 읽게 만든다.
- 비트 구성
	- 00:00-00:08 시리즈 인트로
	- 00:08-00:12 제목 카드
	- 00:13-00:20 발견 (결론 선언)
	- 00:21-00:31 규모와 희귀성 (7000개 중 하나, 본 적 없는 양)
	- 00:32-00:39 관측 근거 1 (수소, 산소, 황 확인)
	- 00:40-00:45 관측 근거 2 (그 원소들이 원반을 이룸). 앞 카드와 말줄임표로 한 문장을 둘로 나눔
	- 00:46-00:52 추론 (해왕성급 행성이 있다)
	- 00:53-01:00 기제 (복사가 대기를 증발시켜 원반이 됨)
	- 01:02-01:08 의미 (우리 태양계의 먼 미래)
	- 01:10-01:22 태그라인, 기관 표기, 크레딧
- 전환점: 00:46 "These clues point to". 그 전까지는 원소와 원반만 보였는데 이 문장에서 화면 시점이 뒤로 물러나며 행성이 처음 등장한다. 관측 사실에서 해석으로 넘어가는 지점이고, 장치는 지시어 "These clues"로 앞의 두 카드를 한데 묶는 것이다. 두 번째 전환은 01:02 "our own Solar System"으로, 먼 천체 이야기가 우리 이야기로 바뀐다.
- 결말: 마지막 카드는 대상을 시청자 쪽으로 끌어오는 의미 부여 문장이다(우리 태양계의 먼 미래). 추정형 might로 여운을 남기고, 장면은 팽창한 태양 앞의 지구형 행성으로 문장을 그대로 그려 준다.
- 문장 작법
	- 카드당 2~4줄, 14~25단어(평균 17단어). 한 카드 한 문장. 긴 문장은 말줄임표로 두 카드에 나눠 싣는다(00:32와 00:40).
	- 전부 평서문. 시제가 논리 순서를 표시한다: has found(결과) → had surveyed(그 전 과정) → confirmed, found(관측) → point to(추론, 현재) → evaporates(기제, 현재) → might look(전망).
	- 주어: 망원경(ESO's Very Large Telescope), Astronomers(익명 복수), Detailed observations, These clues, The radiation, This unique system. 개인 이름이 없다.
	- 수치는 "7000" 하나. 희귀성은 "unlike any other", "never before seen"으로 표현한다.
	- 강조: 카드마다 파란 띠 1~3개. 첫 카드는 세 군데(도구, 대상, 장소)를 나눠 칠해 육하원칙의 뼈대를 표시한다. 뒤로 갈수록 한 구절만 길게 칠한다.
	- 전문어는 한 카드에 하나씩만 새로 넣는다(white dwarf → X-shooter → disc of gas → Neptune-like exoplanet).
- 화면과 문장의 분업: 문장이 "증거 → 추론" 논리를 끌고, 화면은 그 순서에 맞춰 정보를 숨겼다가 보여 준다. 원반 근접 장면에서는 행성이 화면 밖에 있고, 추론 문장이 나오는 순간 시점이 물러나 행성이 보인다. 문장 없는 숨 구간은 카드 사이 2초씩 5번이다. 마지막 장면(붉게 달아오르는 지구형 행성)은 문장이 말하지 않은 "어떻게 보일지"를 그림으로 채운다.
- 수량(대략): 편집 문장 카드 7장, 카드당 평균 17단어(약 104자), 카드 평균 노출 약 6~8초, 본문 전체 121단어(725자). 본문 구간 00:13-01:08, 약 55초.
