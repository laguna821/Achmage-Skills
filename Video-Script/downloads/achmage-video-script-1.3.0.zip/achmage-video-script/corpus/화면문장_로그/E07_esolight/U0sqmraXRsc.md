# ESOcast 137 Light: Temperate Planet Orbiting Quiet Red Dwarf (4K UHD)

- 채널/시리즈: European Southern Observatory (ESO) / ESOcast Light
- URL: https://www.youtube.com/watch?v=U0sqmraXRsc
- 길이: 1분 27초
- 게시일 / 조회수: 2017-11-15 / 150,277
- 음성 유형: 무내레이션(음악만으로 추정). 근거: 제작자가 올린 영어 자막 트랙 7개 문장이 화면에 찍힌 문장 7개와 글자 단위로 같고, 자막 트랙 끝에 "Transcribed by ESO"가 있어 화면 문장을 옮겨 적은 것임을 스스로 밝힌다. 엔딩 크레딧에 음악 제공자(STAN DART)만 있고 내레이터 표기가 없다. 소리 자체는 듣지 못했다.
- 자료: 콘택트시트 4장 (표본 간격 2초), 자막 트랙 있음 (manual/en, 131 words)

## 화면 문장 로그

| 시각 | 화면 문장 (원문) | 장면 | 구분 |
|---|---|---|---|
| 00:02-00:06 | (문장 없음: 시리즈 인트로 6초. 로고 ESOCAST LIGHT) | 원형 HUD 그래픽 안에 망원경 사진 타일(ELT, VLT, LA SILLA, ALMA 라벨) | 제목 |
| 00:08 | **Temperate Planet Orbiting / Quiet Red Dwarf** | 검은 화면, 파란 띠 위 흰 글씨 | 제목 |
| 00:14-00:20 | ESO's exoplanet hunter, HARPS, has / **discovered a temperate planet** just / 11 light-years from Earth. | 은하수 아래 라 시야 관측소 돔, 밤 | 편집 |
| 00:22 | (문장 없음) | 별밭 위에 파란 별자리 선 | |
| 00:24-00:28 | This new world is named Ross 128 b. It's / the **second-closest temperate planet** / known, after Proxima b. | 별밭으로 줌인 | 편집 |
| 00:32 | (문장 없음) | 화면 중앙에 붉은 별 하나 | |
| 00:34-00:40 | It is also the **closest planet to be discovered / orbiting an inactive red dwarf.** | 어두운 행성 가장자리 뒤로 별이 떠오르기 시작 (상상도) | 편집 |
| 00:42-00:46 | The star Ross 128 is quieter than Proxima / Centauri, which is prone to flares of X-rays / and ultraviolet light. | 행성 지평선 위로 떠오른 별 | 편집 |
| 00:48 | (문장 없음) | 행성 가장자리가 밝아짐 | |
| 00:50-00:56 | The inactive nature of Ross 128 could / increase the likelihood this planet **could / potentially sustain life.** | 구름과 지형이 보이는 행성 표면이 드러남 | 편집 |
| 00:58-01:02 | Estimates suggest that the Ross 128 b planet / may have a **temperature close to that of the Earth.** | 행성 전체 구체 | 편집 |
| 01:04 | (문장 없음: 전환) | 행성에서 ELT 돔으로 디졸브 | |
| 01:06-01:10 | It will be a **prime target for ESO's Extremely / Large Telescope,** which may be able to search / for biomarkers, including oxygen. | ELT 돔 3D 애니메이션, 공중 선회 | 편집 |
| 01:12 | (문장 없음) | 돔이 열린 ELT | |
| 01:14 | bite-sized astronomy | 파란 전면 카드 | 제목 |
| 01:16-01:20 | Produced by ESO, / the European Southern Observatory. / Reaching new heights / in Astronomy | ESO 로고, 검은 화면 | 제목 |
| 01:22-01:24 | Music: Music written and performed by STAN DART (www.stan-dart.com). / Footage and photos: ESO, Digitized Sky Survey 2, N. Risinger (skysurvey.org), / L. Calçada, M. Kornmesser, A. Santerne, ACe Consortium. | 검은 화면 크레딧 (앞줄은 표본에서 잘림) | 표기 |

화면 문장과 자막 트랙 대조: 본문 7개 카드가 자막 트랙 7개 큐와 문장, 순서, 시작 시각(00:14, 00:23, 00:34, 00:41, 00:50, 00:58, 01:06)까지 일치한다. 화면에만 있는 것은 파란 형광펜식 강조와 엔딩 크레딧, 자막 트랙에만 있는 것은 "Transcribed by ESO, translated by" 한 줄이다.

## 구조 메모

- 로그라인: 지구에서 11광년 떨어진 조용한 적색왜성 곁에서 온화한 행성이 발견됐고, 별이 조용해서 생명 가능성이 더 높으며 다음 세대 망원경의 1순위 표적이 된다.
- 훅: 인트로와 제목(8초) 뒤 첫 문장이 곧바로 결론이다. 누가(HARPS), 무엇을(온화한 행성), 어디서(11광년)가 한 문장에 다 들어 있다. 궁금증을 만들지 않고 "발견했다"로 시작한다.
- 비트 구성
	- 00:00-00:08 시리즈 인트로
	- 00:08-00:13 제목 카드 (발견 내용을 명사구로 요약)
	- 00:14-00:22 발견 (도구 + 대상 + 거리 수치)
	- 00:23-00:33 이름 붙이기와 순위 1 (두 번째로 가까운 온화한 행성)
	- 00:34-00:40 순위 2 (조용한 적색왜성 중에서는 가장 가까움)
	- 00:41-00:49 비교 (Proxima는 플레어가 잦다)
	- 00:50-00:57 의미 (그래서 생명 가능성이 높아진다)
	- 00:58-01:05 보강 근거 (온도가 지구와 비슷)
	- 01:06-01:13 다음 단계 (ELT가 산소 같은 생체 지표를 찾는다)
	- 01:14-01:27 태그라인, 기관 표기, 크레딧
- 전환점: 00:34 "It is also"와 00:41의 비교 문장. 앞의 두 문장은 "가깝다"만 말했는데, 여기서 기준이 거리에서 별의 성질(조용함)로 바뀐다. 장치는 이미 알려진 이웃(Proxima b)과의 대조다.
- 결말: 마지막 편집 카드는 미래 시제 전망이다(ELT가 산소를 찾을 수 있다). 발견의 끝을 닫지 않고 다음 관측으로 넘긴다. 그 뒤 태그라인 "bite-sized astronomy"와 기관 표어가 형식상 마침표 역할을 한다.
- 문장 작법
	- 카드당 2~3줄, 14~21단어(평균 17단어). 한 카드에 한 문장이 원칙이고 00:24 카드만 두 문장이다.
	- 전부 평서문. 의문문, 감탄문, 말줄임 없음. 현재완료(has discovered)로 시작해 현재형 설명을 거쳐 조동사 전망(could, may, will)으로 끝난다.
	- 주어는 기관의 도구(ESO's exoplanet hunter, HARPS)이거나 천체다. 사람 주어가 한 번도 없다.
	- 수치는 "11 light-years" 하나뿐이고 나머지는 서열어(second-closest, closest)로 규모를 준다.
	- 강조: 카드마다 핵심 구 하나에 파란 형광펜 띠가 깔린다. 강조 구만 이어 읽어도 요지가 된다(discovered a temperate planet / second-closest temperate planet / closest planet ... inactive red dwarf / could potentially sustain life / temperature close to that of the Earth / prime target for ESO's Extremely Large Telescope). 00:42 비교 카드에만 강조가 없다.
	- 추정 표현을 숨기지 않는다(Estimates suggest, may, could potentially).
- 화면과 문장의 분업: 문장이 사실과 논리를 전부 맡고, 장면은 관측소(누가) → 별밭 줌인(어디) → 별이 떠오르는 행성(무엇) → ELT(다음)로 문장의 주어가 바뀔 때마다 바뀐다. 문장이 바뀌는 사이에 2초 안팎의 문장 없는 숨 구간이 4번 있다(00:22, 00:32, 00:48, 01:04). 행성 표면이 서서히 밝아지는 연출이 "생명 가능성" 문장과 맞물린다.
- 수량(대략): 편집 문장 카드 7장, 카드당 평균 17단어(약 100자), 카드 평균 노출 약 7~9초, 본문 전체 119단어(707자). 본문 구간 00:14-01:12, 약 58초.
