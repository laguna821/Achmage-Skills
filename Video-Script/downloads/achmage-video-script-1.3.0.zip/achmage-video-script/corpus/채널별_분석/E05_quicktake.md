## Bloomberg Quicktake (전신 @tictoc by Bloomberg, 현 채널명 Bloomberg News)

### 1. 표본과 형식 판정

| 영상 | 게시 | 길이 | 자료 | 음성 유형 |
|---|---|---|---|---|
| Danica Roem Is Making History (2fLsVK4na8A) | 2018-03 | 1:54 | 시트 5장 | 무내레이션 + 발언으로 추정. 편집 문장 자막이 전편에 깔림 |
| What's Changed Since the Release of Lean In? (fL4aOfUu0_c) | 2018-03 | 1:42 | 시트 4장 | 기자 음성 해설 있음(화면에 "Voice of @clairesuddath" 표기). 해설을 전부 자막으로 띄움 |
| This Couple is Fighting the Coronavirus Side by Side in Wuhan (n0y63uG02sY) | 2020-03 | 2:18 | 시트 6장 | 무내레이션 + 현장 발언(번역 자막)으로 추정 |
| Utah Monolith (_orpeenBXVk) | 2020-11 | 1:37 | 시트 4장 + 자막 트랙 | 무내레이션 + 현장음. 화면 문장은 헤드라인 1개 |
| Why No One Smokes In Sweden (kDpPx0wozhU) | 2024-01 | 5:09 | 자막 트랙만 | 내레이션 있음(해설 리포트) |
| Young Professionals Share Their Ideal WFH Friday (xl0AcsxlQeY) | 2022-09 | 4:03 | 자막 트랙만 | 인터뷰 중심, 해설자 없음 |

- 형식 판정: 한 채널 안에 네 가지 형식이 섞여 있다. "화면 문장이 이야기를 끄는 형식"에 온전히 해당하는 것은 2018년 TicToc 시절의 프로필 영상(Danica Roem) 한 편이다.
	- 문장 주도형(Danica Roem): 편집 문장 14장이 인물 소개 전체를 끈다.
	- 해설 자막형(Lean In): 말로 하는 해설을 글자 그대로 화면에 띄운다. 소리를 꺼도 같은 대본을 읽게 된다.
	- 관찰형(우한 부부, 유타): 편집 문장은 도입 20초 이하에만 있고 나머지는 발언 자막이나 장면만 흐른다.
	- 방송 리포트형(스웨덴, 재택 금요일): 2022년 이후. 말이 중심이다. 화면은 확인하지 못했다.
- 표본의 한계: 프레임 4편은 모두 1분 반에서 2분대의 소셜용 단신이고, 숫자를 본격적으로 다루는 5분짜리 리포트(스웨덴)는 화면이 없다. 그래서 "데이터를 그래픽과 문장으로 어떻게 나누는가"는 이 표본으로 답할 수 없다. 숫자에 관한 관찰은 화면 자막 2편(Danica Roem, Lean In)과 음성 1편(스웨덴)의 문장에서만 얻었다. 자막 트랙이 없는 3편은 소리를 확인하지 못했다.

### 2. 대본의 뼈대

- 프로필형(Danica Roem, 1:54): 당사자 발언 4초 / 코너 타이틀(이름, 직함) / 핵심 한 단어를 큰 글씨로 / 같은 사실을 문장으로 / 이력 / 당선과 상대 / 당선 후 한 일 / 흐름으로 넓히기와 수치 2개 / 의미 정리 / 당사자 발언으로 종료. 한 비트는 6~12초.
- 해설형(Lean In, 1:42 / 스웨덴, 5:09): 훅(장면 병렬 또는 인물) / 논지 한 문장 / 수치 묶음 / 처방 또는 통념 / "그런데" 반전 / 논의 넓히기 / 유보형 결말. 스웨덴은 여기에 "찬성 근거, 반대 근거, 대안 설명"의 3단이 더 들어간다.
- 관찰형(우한 부부, 2:18 / 유타, 1:37): 타이틀 한 문장 / 상황 설정 0~2문장 / 이후 문장 없이 장면과 현장 발언 / 정리 없이 로고.
- 인터뷰 병치형(재택 금요일, 4:03): 예고 발언 2개 / 자기소개 / 하루의 시간순으로 두 사람의 답을 번갈아 / 하루의 끝에서 종료.
- 시간 배분의 공통점: 어느 유형이든 15~28초 안에 "누가, 무엇을, 왜 지금"이 끝난다. 프레임 4편은 첫 4초 안에 주제를 밝힌다.

### 3. 도입부(훅)

- 헤드라인 선제시형: 첫 프레임에 뉴스 제목체 한 문장과 결과 화면을 함께 준다.
	- "Crew finds metallic / monolith in Utah desert" (유타)
	- "The couple / fighting the / virus together" (우한 부부)
- 당사자 단언형: "I am a transgender woman. / We won because I am a transgender woman." (Danica Roem)
- 시점 병렬형: "Five years ago this month, the Weinstein Company / had just won three Oscars. / Donald Trump's Miss Universe was planning a pageant in Moscow. / And Sheryl Sandberg released her book 'Lean In,'" (Lean In. 같은 문형 세 개의 마지막에 본론을 놓는다)
- 인물 소개형(음성): "This is Morton, he's 20 years old and has just picked up a few fresh packs of snus" (스웨덴)
- 예고편형(음성): 본편에서 가장 좋은 답 두 줄을 미리 들려줌 (재택 금요일)

### 4. 정보 공개 순서와 전환 장치

- 답 먼저. 유타는 결과물(기둥)을 먼저 보여 주고 발견 과정을 뒤에 붙인다. Danica Roem은 "ONLY"와 "first"를 16초 안에 말하고 나서 이력으로 간다.
- 사람에서 흐름으로 넓히기: "Women like Roem have set the pace for November's midterm elections in the U.S." (Danica Roem 01:08. 주어를 한 사람에서 집단으로 바꾸고 수치를 붙인다)
- 최단 문장 뒤 뒤집기: "And they did." 이어 "And yet they're still less likely to get them." (Lean In 00:54-01:02)
- 수치 대 수치: 흡연율 5%대 직후 "but about 15% of the population uses snus" (스웨덴 00:59, 음성)
- 한 단어 접속사: Still, But, And yet, Despite, Instead (Lean In, 스웨덴)
- 화자 색으로 인물 등장시키기: 우한 부부에서 아내의 첫 대사가 청록색 자막으로 나오는 순간(01:20) 병구완 영상이 부부 이야기로 바뀐다.
- 미루는 것: 해설형 두 편은 판정을 끝까지 미룬다. 스웨덴은 제목의 전제를 뒤집는 대안 설명을 3분 58초에야 내놓는다.

### 5. 결말 처리

- 당사자 인용 + 수미상관: "be who you are, and be that well, / and be you better than anyone else ever could." (Danica Roem. 첫 장면과 같은 현장으로 돌아감)
- 예고형 여운: "This week Bloomberg Businessweek takes a look at a movement / and finds that actually, it's just getting started." (Lean In)
- 정리 없이 끊기: 우한 부부는 대화 도중에, 유타는 기둥 화면에서 로고로 넘어간다.
- 전문가의 유보 발언(음성): "we still have a lot more to do before becoming a smoke free country" (스웨덴)
- 하루의 끝과 영상의 끝 맞추기(음성): "just indulging in the silence" (재택 금요일)
- 모든 영상이 팔로우·구독 안내 카드로 끝난다("Follow @QuickTake", "Watch the latest update @tictoc", "Subscribe").

### 6. 문장 작법

- 분량: 편집 문장은 하단 중앙 2줄 자막이 기본이다. Danica Roem은 카드당 9~10단어를 약 6초씩, Lean In은 카드당 9~10단어를 약 3초씩 띄운다. 우한 부부의 편집 문장은 카드당 3~5단어. 유타는 7단어짜리 헤드라인 하나.
- 편집 문장에는 마침표를 찍지 않고(Danica Roem, 우한 부부, 유타), 발언 자막과 해설 자막에는 찍는다.
- 한 문장을 분사구와 관계절로 이어 2~3카드에 건다("She won ... / defeating an incumbent Virginia lawmaker / who would have restricted which bathroom she could use").
- 강조: 가장 중요한 한 단어를 자막에서 빼내 화면 전체 타이포로 세운다("**ONLY** openly transgender person in the U.S. State Legislature"). 그 밖에는 색 강조를 거의 쓰지 않는다.
- 편집과 인용의 구분: 서체(굵은 기울임체 대 곧은 일반체, Danica Roem), 굵기(우한 부부), 색(우한 부부의 화자 구분).

숫자·데이터를 문장으로 옮기는 방식(요청 사항 a):

- 절대값보다 비교로 쓴다. Lean In의 수치 8개는 전부 비교 형태다: "about 20% less than what men do", "6% of all Fortune 500 company CEOs", "about 20% of Congress", "at about the same rate as men", "a third as much housework", "twice as much childcare".
- 수치 뒤에 바로 기준점을 댄다: 5.6%를 말하고 곧 "the lowest percentage in Europe", "within touching distance of the 5% target" (스웨덴, 음성).
- 어림수와 확실성 표지를 함께 쓴다: "Nearly 500 women are likely to run for congress", "200 more may put in bids" (Danica Roem) / "about", "as much as", "projected" (스웨덴).
- 수치 앞에 읽는 법을 알려 주는 부사를 붙인다: "only 5.6%", "still earn ... less", "record numbers".
- 처음에는 정확한 값, 반복할 때는 어림값(5.6%에서 5%로, 스웨덴).
- 전망은 출발값과 도착값을 한 문장에 넣는다: "from about $2 billion in 2022 to as much as 17.6 billion by 2029" (스웨덴).
- 한 카드에 수치 하나. 2~3개를 연달아 쓸 때는 영역을 달리한다(임금, 기업, 의회 / 승진, 가사, 육아).
- 수치는 구획 하나에 몰아 쓰고 나머지 구간은 사람과 장면으로 채운다. Danica Roem은 01:14-01:30에만, 스웨덴은 세 구간에만 수치가 있다.
- 날짜는 문장 밖 라벨로 뺄 수 있다(유타의 "November 18" 상자).
- 수치를 양보절 뒤에 놓아 낙차를 만든다: "Despite women earning more college and graduate degrees than men, ... they still earn collectively about 20% less" (Lean In).

### 7. 화면과 문장의 분업

소리를 꺼도 이해되게 만드는 장치(요청 사항 b). 프레임 4편에서 확인한 것:

1. 첫 프레임 헤드라인: 영상이 시작되는 순간 주제 한 문장이 화면에 있다(유타, 우한 부부). 소리가 들리기를 기다리지 않는다.
2. 말은 전부 자막으로: 발언(Danica Roem, 우한 부부)도 해설(Lean In)도 화면에 글자로 있다. 외국어 발화는 번역 자막이 원음을 대신한다(우한 부부).
3. 화자 표시를 화면에 고정: "Voice of @clairesuddath" 표기가 영상 내내 떠 있어, 자막이 누구의 목소리인지 소리 없이 안다(Lean In). 대화 장면에서는 글자 색으로 화자를 가른다(우한 부부).
4. 편집 문장과 인용의 시각적 구분: 서체와 굵기로 "설명"과 "말"을 구분한다(Danica Roem).
5. 코너 타이틀 카드: "Profile / Danica Roem / Member of the Virginia House of Delegates", "On Location / Claire Suddath / Bloomberg Businessweek / New York". 형식과 인물과 직함을 한 장에 준다.
6. 핵심어 대형 타이포: 스크롤하던 눈을 멈추게 하는 한 단어(ONLY).
7. 문장과 장면의 일대일 대응: "bathroom"에 화장실 표지판, "Congress"에 의사당, "degrees"에 학사모. 문장을 놓쳐도 그림이 단어를 알려 준다.
8. 구석 라벨: 날짜 상자와 출처 표기(유타). 문장에 넣지 않아도 되는 정보를 구석으로 뺀다.
9. 진행 막대: 헤드라인 위의 민트색 막대(유타). 문장이 얼마나 더 떠 있을지 알려 주는 장치로 보인다.
10. 정사각형 화면과 큰 글씨: 세로로 넘기는 피드에서 읽히도록 2020년 영상 두 편은 정사각형이다.

- 장면에 맡기는 것: 관찰형 두 편은 문장 없는 시간이 전체의 40~80%다. 방호복을 입는 동작, 떨어져 앉은 식탁, 기둥 옆에 선 사람의 크기는 문장 없이 전달된다.
- 반대 사례: 스웨덴 리포트와 재택 금요일은 음성 구성만 보면 말에 실린 정보가 많아(분당 130~190단어) 자막 없이는 무음 시청이 어렵다. 2018~2020년의 소셜용 설계와 2022년 이후의 유튜브용 설계가 다르다는 점은 표본에서 읽히지만, 뒤 두 편의 화면을 보지 못해 단정하지 않는다.

### 8. 영상별 구조 요약

| 영상 | 길이 | 훅 유형 | 전개 구조 | 전환 장치 | 결말 유형 |
|---|---|---|---|---|---|
| Danica Roem Is Making History | 1:54 | 당사자 단언 + 타이틀 카드 + 대형 타이포 | 프로필: 사실, 이력, 당선, 입법, 흐름 | 주어를 개인에서 집단으로 + 수치 2개 | 당사자 인용, 첫 현장 회귀 |
| What's Changed Since the Release of Lean In? | 1:42 | 5년 전 세 장면 병렬 + 논지 한 문장 | 해설: 동기, 수치, 처방, 반전, 논의의 진화 | "And they did." 뒤 "And yet" | 본편 기사 예고("just getting started") |
| This Couple is Fighting the Coronavirus | 2:18 | 3줄 타이틀 + 편집 문장 2문장 | 관찰: 하루의 장면들과 부부의 대화 | 화자 색(아내의 첫 대사) | 정리 없이 대화 중 종료 |
| Utah Monolith | 1:37 | 헤드라인 + 결과 화면 | 관찰: 접근, 살펴보기, 근접 | 없음(장면이 크기를 드러냄) | 문장 없이 로고 |
| Why No One Smokes In Sweden (음성만) | 5:09 | 인물 소개 + 조건부 논지 | 해설: 수치, 반전 수치, 산업, 찬성, 반대, 대안 설명 | 수치 대 수치, "Still,", 대안 인과 | 전문가의 유보 발언 |
| Young Professionals Share Their Ideal WFH Friday (음성만) | 4:03 | 예고 발언 2개 | 하루의 시간순, 두 사람 교차 | 예고 문장의 회수 | 하루의 끝("silence") |

### 9. 대본 스킬로 가져갈 규칙

1. 첫 프레임에 주제 한 문장을 띄워라. 주어, 동사, 목적어, 장소만 남긴 헤드라인체로 7단어 안팎에 맞춰라. (유타, 우한 부부)
2. 가장 중요한 한 단어는 자막에서 빼내 화면 전체 타이포로 따로 세워라. (Danica Roem의 "ONLY")
3. 수치는 절대값으로 두지 말고 비교로 바꿔 써라. "얼마"가 아니라 "무엇의 몇 분의 몇, 누구보다 몇 배"로 쓰고, 한 카드에 하나만 넣어라. (Lean In, Danica Roem)
4. 수치를 말한 다음 문장에서 곧바로 기준점(순위, 목표치, 과거 값)을 대라. 불확실한 수치에는 nearly, about, likely 같은 표지를 문장 안에 넣어라. (스웨덴, Danica Roem)
5. 수치는 한 구획에 2~3개를 몰아 쓰되 서로 다른 영역에서 하나씩 가져오고, 그 앞뒤는 사람과 장면으로 채워라. (Lean In, 스웨덴)
6. 기대를 세우는 가장 짧은 문장을 놓고 바로 다음 카드에서 접속사 하나로 뒤집어라. (Lean In의 "And they did." / "And yet")
7. 편집 문장, 인용, 화자를 서체와 색과 고정 라벨로 구분해 소리 없이도 "누가 말하는지" 알게 하라. (Danica Roem, 우한 부부, Lean In)
8. 장면이 스스로 설명하는 영상에서는 상황 설정 두 문장만 쓰고 물러나라. 직업, 경위, 관계처럼 장면으로 알 수 없는 것만 문장으로 써라. (우한 부부, 유타)

### 10. 한계와 주의

- 프레임 표본 4편이 모두 2분 안팎의 단신이다. Brut이나 지식채널e처럼 3~5분을 편집 문장으로 끌고 가는 사례는 이 그룹에 없다.
- 숫자를 그래프나 인포그래픽으로 보여 주는 화면은 표본에 한 번도 나오지 않았다. Quicktake의 데이터 시각화 방식은 이 자료로 판단할 수 없다.
- 스웨덴, 재택 금요일 두 편은 음성만 보았다. 화면 자막과 그래픽이 음성과 어떻게 겹치는지 확인하지 못했다.
- 자막 트랙이 없는 3편(Danica Roem, Lean In, 우한 부부)은 소리를 확인하지 못했다. Danica Roem의 편집 문장을 읽는 목소리가 있는지, Lean In의 자막이 음성과 글자 그대로 같은지는 추정이다.
- 유타 영상은 01:12-01:16 구간 프레임이 시트에 없다(로고 구간으로 보임). 우한 부부 영상은 00:16 무렵 남편을 소개하는 주어 부분이 표본에서 빠졌다.
- 2018년 두 편은 조회수가 100회대여서 시청 반응으로 형식의 효과를 가늠할 수 없다.
- 채널명과 브랜드가 세 번 바뀌었다(TicToc, Quicktake, Bloomberg News). 시기별 형식 차이가 채널 방침 때문인지 플랫폼(트위터용, 유튜브용) 때문인지는 이 표본으로 가릴 수 없다.
- 영어 헤드라인체(관사 생략, 현재형)는 한국어로 옮길 때 명사형 종결이나 "-다" 현재형 가운데 무엇이 대응하는지 따로 시험해야 한다.
