import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,join,relative} from 'node:path';
import assert from 'node:assert/strict';
import {routes,publicPack} from '../skill/hallym-kordoc/scripts/catalog.mjs';
import {parse} from '../skill/hallym-kordoc/scripts/engine.mjs';
import {execute} from '../skill/hallym-kordoc/scripts/run.mjs';
import {hash} from '../skill/hallym-kordoc/scripts/common.mjs';
const root=resolve('validation/content-'+Date.now());await mkdir(root,{recursive:true});
const normalize=s=>s.replace(/[\\\s*_]/g,'');const forms=[];
for(const r of routes.filter(r=>r.templateStatus==='reference-reconstructed')){
 const p=await publicPack(r.id),parsed=await parse(Buffer.from(p.hallym.templateBase64,'base64'),{images:false});assert.ok(parsed.success);
 const text=normalize(parsed.markdown);
 for(const phrase of [...r.notes,...r.signatures])assert.ok(text.includes(normalize(phrase)),r.id+' missing phrase: '+phrase.slice(0,40));
 forms.push({familyId:r.id,requiredNotes:r.notes.length,signatureLabels:r.signatures.length,status:'passed'});
}
const session=JSON.parse(await readFile('validation/sessions/claude/reuse-report.json'));
const req=JSON.parse(await readFile(session.requests.compose));
process.env.HALLYM_KORDOC_HOME=resolve('validation/sessions/claude/state');process.env.KORDOC_OFFLINE='1';
const result=await execute({...req,outputDir:join(root,'claude-final-replay')});assert.equal(result.status,'success');assert.equal(result.templateSource,'explicit-private');
const actual=result.files.find(f=>f.name==='document.hwpx');const original=session.outputs.find(f=>f.path.endsWith('document.hwpx'));
assert.equal(actual.sha256,original.sha256);
const report={status:'passed',forms,claudeRequestReplay:{status:'passed',kind:'saved JSON replay in final runtime; not another model session',templateHash:result.templateHash,templateSource:result.templateSource,priorRunnerSha256:session.skill.runnerSha256,finalRunnerSha256:hash(await readFile('skill/hallym-kordoc/scripts/run.mjs')),hwpxSha256:actual.sha256,identicalToFreshSessionOutput:true}};
await writeFile(join(root,'report.json'),JSON.stringify(report,null,2));await writeFile('validation/latest-content-check.json',JSON.stringify({path:relative(resolve('.'),join(root,'report.json')).replaceAll('\\','/'),...report},null,2));console.log(JSON.stringify(report));
