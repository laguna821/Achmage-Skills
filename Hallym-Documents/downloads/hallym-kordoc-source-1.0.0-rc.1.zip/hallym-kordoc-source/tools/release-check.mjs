import {readFile,writeFile,mkdir,lstat} from 'node:fs/promises';
import {resolve,join,dirname,relative,isAbsolute} from 'node:path';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {JSZip} from '../skill/hallym-kordoc/scripts/xml.mjs';
import {hash} from '../skill/hallym-kordoc/scripts/common.mjs';
const root=resolve('validation/release-'+Date.now());await mkdir(root,{recursive:true});
const zipBytes=await readFile('dist/hallym-kordoc-1.0.0-rc.1.zip'),zip=await JSZip.loadAsync(zipBytes);
for(const [name,entry] of Object.entries(zip.files)){
 const path=resolve(root,'extracted',name),rel=relative(join(root,'extracted'),path);
 assert.ok(!rel.startsWith('..')&&!isAbsolute(rel));
 if(entry.dir)continue;await mkdir(dirname(path),{recursive:true});await writeFile(path,await entry.async('nodebuffer'));
}
const skill=join(root,'extracted/hallym-kordoc'),manifest=JSON.parse(await readFile(join(skill,'PACKAGE-MANIFEST.json')));
for(const f of manifest.files)assert.equal(hash(await readFile(join(skill,f.path))),f.sha256,f.path);
const templates=await JSZip.loadAsync(await readFile(join(skill,'assets/templates.zip')));let templateCount=0;
for(const [name,e] of Object.entries(templates.files)){
 if(e.dir)continue;const text=await e.async('string');assert.ok(!/C:[\\/]+Users[\\/]+/.test(text),name);
 const p=JSON.parse(text);assert.equal(p.engine.version,'4.18.13');
 const hwpx=await JSZip.loadAsync(Buffer.from(p.hallym.templateBase64,'base64'));
 assert.equal(await hwpx.file('mimetype').async('string'),'application/hwp+zip');templateCount++;
}
assert.equal(templateCount,34);
const env={...process.env,HALLYM_KORDOC_HOME:join(root,'state'),KORDOC_WORKBENCH_CACHE:join(root,'empty-cache'),KORDOC_OFFLINE:'1'};
const call=(args,input)=>{const r=spawnSync(process.execPath,args,{cwd:root,env,input:input&&JSON.stringify(input),encoding:'utf8'});return {code:r.status,stdout:r.stdout,stderr:r.stderr};};
const run=req=>{const r=call([join(skill,'scripts/run.mjs')],{schemaVersion:1,...req});return JSON.parse(r.stdout);};
const selected=run({mode:'resolve',prompt:'일반 보고서를 한림대학교 양식으로 작성해줘'});assert.equal(selected.selection.familyId,'report.hallym');
const request={mode:'compose',familyId:'report.hallym',title:'독립 배포 검증',values:{department:'합성 부서',purpose:'배포 검증'},sections:Object.fromEntries(selected.recipe.sections.map(x=>[x,'합성 검증 내용']))};
const a=run({...request,outputDir:join(root,'doc-a')}),b=run({...request,outputDir:join(root,'doc-b')});
assert.equal(a.status,'success',JSON.stringify(a));assert.equal(b.status,'success');
assert.equal(a.files[0].sha256,b.files[0].sha256);
const readback=run({mode:'read',input:a.files[0].path,outputDir:join(root,'readback')});assert.equal(readback.status,'success');
const installer=[join(skill,'scripts/install.mjs'),'--codex','--claude','--project',join(root,'project')];
assert.equal(call(installer).code,0);assert.equal(call(installer).code,0);
const conflict=join(root,'unmanaged/.agents/skills/hallym-kordoc');await mkdir(conflict,{recursive:true});await writeFile(join(conflict,'keep.txt'),'preserve');
const rejected=call([join(skill,'scripts/install.mjs'),'--codex','--project',join(root,'unmanaged')]);assert.notEqual(rejected.code,0);assert.match(rejected.stderr,/EXISTING_UNMANAGED_SKILL/);assert.equal(await readFile(join(conflict,'keep.txt'),'utf8'),'preserve');
const report={status:'passed',archiveSha256:hash(zipBytes),bytes:zipBytes.length,manifestFiles:manifest.files.length,templateCount,offlineCore:'passed',isolatedExtraction:'passed',node:process.version,nodeProvisioning:'unverified; preinstalled Node used',installerIdempotency:'passed',unmanagedDirectoryPreserved:'passed',deterministicProcesses:'passed',outputSha256:a.files[0].sha256,engine:manifest.engine,research:manifest.research};
await writeFile(join(root,'report.json'),JSON.stringify(report,null,2));await writeFile('validation/latest-release-check.json',JSON.stringify({path:relative(resolve('.'),join(root,'report.json')).replaceAll('\\','/'),...report},null,2));console.log(JSON.stringify(report));
