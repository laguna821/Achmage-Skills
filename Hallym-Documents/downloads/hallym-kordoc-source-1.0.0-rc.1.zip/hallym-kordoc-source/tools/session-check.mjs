import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {spawn} from 'node:child_process';
import {homedir} from 'node:os';
const provider=process.argv[2],phase=process.argv[3]||'create';
if(!['codex','claude'].includes(provider)||!['create','reuse'].includes(phase))throw Error('provider and phase required');
const project=resolve('validation/sessions/'+provider),state=join(project,'state');await mkdir(project,{recursive:true});
const env={...process.env,HALLYM_KORDOC_HOME:state,KORDOC_OFFLINE:'1'};delete env.CODEX_THREAD_ID;delete env.CODEX_SESSION_ID;
const skill=resolve('skill/hallym-kordoc'),install=spawn(process.execPath,[join(skill,'scripts/install.mjs'),'--'+provider,'--project',project,'--update'],{env,stdio:'pipe'});
let installOutput='';install.stdout.on('data',x=>installOutput+=x);install.stderr.on('data',x=>installOutput+=x);
await new Promise((yes,no)=>install.on('exit',code=>code===0?yes():no(Error(installOutput))));
await writeFile(join(project,'install-'+phase+'.json'),installOutput);
const prompt=phase==='create'?
'hallym-kordoc 스킬로 한림대학교 일반 보고서를 만들어 주세요. 합성 검증 자료이며 실제 사업 실적이 아닙니다. 제목은 미디어콘텐츠 기획 기반 실습 제안, 제출 부서는 미디어스쿨, 보고 목적은 기획 문서를 활용한 실습 수업 제안입니다. 추진 배경: 비전공 학생도 요구사항과 사용자 흐름을 먼저 정의할 필요가 있습니다. 현황과 문제: 실행 전에 목표와 평가 기준을 명확히 하는 연습이 부족합니다. 제안 내용: 학생이 기획서와 화면 흐름을 작성한 뒤 AI 도구로 시제품을 만들고 동료 검토를 합니다. 추진 일정: 1주 기획, 2주 시제품, 3주 검토. 기대효과: 기획과 검증 역량을 기릅니다. HWPX·Markdown·미리보기를 새 결과 폴더에 만들고 결과를 재읽어 확인해 주세요. 사용한 공용 보고서 양식 패키지를 내보내서 개인 라이브러리에 등록하고 report.hallym 업무 전체에 연결해 주세요. 최종 session-report.json에는 사용한 스킬 경로, 양식 해시, 산출물 절대경로, 실행 상태와 미검증 사항을 기록해 주세요. 원본 스킬 파일을 수정하지 마세요.':
'새 세션입니다. hallym-kordoc 스킬로 개인 라이브러리에서 이전에 등록한 report.hallym 보고서 양식을 찾아 재사용해 주세요. 제목은 미디어콘텐츠 시제품 평가 계획, 제출 부서는 미디어스쿨, 보고 목적은 학생 시제품 검토 계획입니다. 배경은 동료 피드백의 질 향상, 현황과 문제는 평가 기준 불명확, 제안 내용은 기능 동작·사용자 흐름·근거 설명을 점검표로 평가하는 것입니다. 일정은 1주 기준 합의, 2주 상호평가. 기대효과는 개선 근거의 명료화입니다. 이는 합성 검증 자료입니다. 새 결과 폴더에 HWPX·Markdown·미리보기를 만들고 재읽기로 이전 보고서 내용이 남지 않았는지 확인해 주세요. reuse-report.json에 실제 사용한 스킬 경로·저장 양식 해시·산출물 절대경로·실행 상태를 기록해 주세요. 스킬이나 원본을 수정하지 마세요.';
await writeFile(join(project,phase+'-prompt.txt'),prompt);
const args=provider==='codex'?['exec','--skip-git-repo-check','--sandbox','workspace-write','--json','-C',project,'-']:['-p','--output-format','json','--permission-mode','acceptEdits','--allowedTools','Read,Write,Edit,Bash(node *),Bash(powershell *),Bash(pwsh *),Bash(mkdir *),Bash(cat *),Bash(ls *),Bash(python *),Bash(python3 *)','--add-dir',skill];
const command=provider==='codex'?(process.env.HALLYM_CODEX_BIN||'codex'):(process.env.HALLYM_CLAUDE_BIN||join(homedir(),'.local/bin/claude.exe'));
const child=spawn(command,args,{cwd:project,env,stdio:['pipe','pipe','pipe'],windowsHide:true});
let stdout='',stderr='';child.stdout.on('data',x=>stdout+=x);child.stderr.on('data',x=>stderr+=x);child.stdin.end(prompt);
const code=await new Promise(yes=>child.on('exit',yes));
await writeFile(join(project,phase+'-stdout.log'),stdout);await writeFile(join(project,phase+'-stderr.log'),stderr);
console.log(JSON.stringify({provider,phase,exitCode:code,project,stdoutBytes:stdout.length,stderr:stderr.slice(-1000)}));process.exitCode=code||0;
