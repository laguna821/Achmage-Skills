import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,join,dirname,relative,isAbsolute} from 'node:path';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {JSZip} from '../skill/hallym-kordoc/scripts/xml.mjs';
import {hash} from '../skill/hallym-kordoc/scripts/common.mjs';
const root=resolve('validation/source-'+Date.now()),zip=await JSZip.loadAsync(await readFile('dist/hallym-kordoc-source-1.0.0-rc.1.zip'));await mkdir(root,{recursive:true});
for(const [name,e] of Object.entries(zip.files)){
 if(e.dir)continue;assert.ok(!/\.(hwp|exe|dll|onnx|ttf|otf)$/i.test(name));
 const path=resolve(root,name),rel=relative(root,path);assert.ok(!rel.startsWith('..')&&!isAbsolute(rel));
 const b=await e.async('nodebuffer');if(/\.(md|json|mjs|ps1|txt)$/i.test(name))assert.ok(!/[A-Z]:[\\/]+Users[\\/]+/.test(b.toString()),name);
 await mkdir(dirname(path),{recursive:true});await writeFile(path,b);
}
const cwd=join(root,'hallym-kordoc-source'),run=spawnSync(process.execPath,['tools/build.mjs'],{cwd,encoding:'utf8',env:{...process.env,KORDOC_OFFLINE:'1'}});
assert.equal(run.status,0,run.stdout+run.stderr);
for(const file of ['catalog.json','assets/templates.zip'])assert.equal(hash(await readFile(join(cwd,'skill/hallym-kordoc',file))),hash(await readFile(join('skill/hallym-kordoc',file))),file);
const result={status:'passed',sourceArchiveSha256:hash(await readFile('dist/hallym-kordoc-source-1.0.0-rc.1.zip')),standaloneBuild:'passed',byteIdenticalCatalogAndTemplates:true,privacyScan:'passed',fixtures:'not bundled',node:process.version};
await writeFile('validation/source-check.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
