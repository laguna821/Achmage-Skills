import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {recipes} from './recipes.mjs';
import {skeleton,generateStyled,fixedTemplate} from '../skill/hallym-kordoc/scripts/layout.mjs';
import {hash,packHash,ENGINE,RESEARCH} from '../skill/hallym-kordoc/scripts/common.mjs';
import {JSZip} from '../skill/hallym-kordoc/scripts/xml.mjs';
import {parse} from '../skill/hallym-kordoc/scripts/engine.mjs';
const root=resolve(fileURLToPath(new URL('..',import.meta.url))),skill=join(root,'skill/hallym-kordoc');
const sources=JSON.parse(await readFile(join(root,'tools/public-sources.json'),'utf8'));
const catalog={routes:JSON.parse(await readFile(join(root,'tools/research-families.json'),'utf8'))};
const zip=new JSZip(),items=[],validation=[];
for(const recipe of recipes){
 const candidate=catalog.routes.find(r=>r.id===recipe.id);
 if(!candidate)throw Error('Unknown research family: '+recipe.id);
 const source=sources.find(s=>s.id===recipe.sourceId);
 if(source)recipe.source={id:source.id,name:source.name,url:source.url,sha256:source.sha256,format:'hwp',accessedAt:'2026-10-07'};
 if(recipe.noticeSource){
  const s=sources.find(x=>x.id===recipe.noticeSource);
  if(!s?.notice)throw Error('Pinned public consent notice not found');
  recipe.notes.push(s.notice);delete recipe.noticeSource;
 }
 const markdown=skeleton(recipe,{}, {},{},true);
 const bytes=recipe.strategy==='fixed'?await fixedTemplate(recipe):(await generateStyled(markdown,recipe)).bytes;
 const parsed=await parse(bytes,{images:false});
 if(!parsed.success)throw Error('Roundtrip failed '+recipe.id);
 const pack={kind:'kordoc-template-pack',schemaVersion:1,id:'hallym-'+recipe.id,version:recipe.version,name:recipe.title,source:recipe.source||{name:'새 공용 초안',format:'markdown',sha256:hash(markdown)},engine:ENGINE,markdownSkeleton:markdown,fields:recipe.fields,tableRules:[],assets:[],evidence:[{authority:recipe.source?'public-reference-reconstruction':'authored-blank',research:RESEARCH}],limitations:recipe.limitations,validation:{structural:'passed',visual:'pending',hancom:'pending'},hallym:{familyId:recipe.id,recipe,templateBase64:bytes.toString('base64'),templateSha256:hash(bytes)}};
 pack.contentHash=packHash(pack);
 zip.file(recipe.id+'.kordoc-template.json',JSON.stringify(pack),{date:new Date('2000-01-01T00:00:00Z')});
 items.push({...recipe,source:recipe.source,packHash:pack.contentHash,archiveEntry:recipe.id+'.kordoc-template.json',selectionKeys:candidate.selectionKeys,qualificationNotes:candidate.qualificationNotes});
 validation.push({familyId:recipe.id,templateStatus:recipe.templateStatus,bytes:bytes.length,sha256:hash(bytes),parsed:true});
}
if(items.length!==34)throw Error('Expected 34 families');
await mkdir(join(skill,'assets'),{recursive:true});
await writeFile(join(skill,'assets/templates.zip'),await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE',compressionOptions:{level:9}}));
await writeFile(join(skill,'catalog.json'),JSON.stringify({schemaVersion:1,kind:'hallym-kordoc-catalog',version:'1.0.0-rc.1',research:RESEARCH,engine:ENGINE,routes:items},null,2));
await mkdir(join(root,'validation'),{recursive:true});
await writeFile(join(root,'validation/build.json'),JSON.stringify(validation,null,2));
console.log(JSON.stringify({families:items.length,fixed:items.filter(x=>x.strategy==='fixed').length,referenceReconstructed:items.filter(x=>x.source).length,templateBytes:(await readFile(join(skill,'assets/templates.zip'))).length}));
