import {readFile,writeFile,readdir,mkdir,cp} from 'node:fs/promises';
import {resolve,join,relative} from 'node:path';
import {JSZip} from '../skill/hallym-kordoc/scripts/xml.mjs';
import {hash,ENGINE,RESEARCH} from '../skill/hallym-kordoc/scripts/common.mjs';
const root=resolve('skill/hallym-kordoc'),dist=resolve('dist');await mkdir(dist,{recursive:true});
const files=[];
async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=join(dir,e.name);if(e.isDirectory())await walk(p);else{const name=relative(root,p).replaceAll('\\','/');if(name==='PACKAGE-MANIFEST.json')continue;if(/\.(hwp|exe|dll|onnx|ttf|otf)$/i.test(name))throw Error('Unexpected heavyweight/private input: '+name);const data=await readFile(p);if(/\.(md|json|mjs|py|ps1|sh|txt|yaml)$/i.test(name)&&/C:[\\/]+Users[\\/]+/.test(data.toString()))throw Error('Private path/name in '+name);files.push({path:name,bytes:data.length,sha256:hash(data)});}}}
await walk(root);
files.sort((a,b)=>a.path.localeCompare(b.path));
const manifest={schemaVersion:1,name:'hallym-kordoc',version:'1.0.0-rc.1',engine:ENGINE,research:RESEARCH,profile:'local-core',networkRequiredAtUse:false,certification:{contractTests:'see external validation report',hancom:'unverified',freshSessions:'see external validation report',web:'deferred'},files};
await writeFile(join(root,'PACKAGE-MANIFEST.json'),JSON.stringify(manifest,null,2));
const zip=new JSZip();for(const f of [...files,{path:'PACKAGE-MANIFEST.json'}])zip.file('hallym-kordoc/'+f.path,await readFile(join(root,f.path)),{date:new Date('2000-01-01T00:00:00Z')});
const bytes=await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE',compressionOptions:{level:9}});
if(bytes.length>10_000_000)throw Error('Core ZIP exceeds 10 MB budget');
await writeFile(join(dist,'hallym-kordoc-1.0.0-rc.1.zip'),bytes);
await writeFile(join(dist,'SHA256SUMS'),hash(bytes)+'  hallym-kordoc-1.0.0-rc.1.zip\n');
await writeFile(join(dist,'package-report.json'),JSON.stringify({bytes:bytes.length,files:files.length+1,sha256:hash(bytes),engine:ENGINE},null,2));
console.log(JSON.stringify({bytes:bytes.length,files:files.length+1,sha256:hash(bytes)}));
