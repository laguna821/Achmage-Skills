import {readFile,writeFile,readdir,mkdir,cp} from 'node:fs/promises';
import {join,relative,resolve} from 'node:path';
import {JSZip} from '../skill/hallym-kordoc/scripts/xml.mjs';
import {routes,publicPack} from '../skill/hallym-kordoc/scripts/catalog.mjs';
import {hash} from '../skill/hallym-kordoc/scripts/common.mjs';
const dist=resolve('dist');await mkdir(dist,{recursive:true});const date=new Date('2000-01-01T00:00:00Z');
const outputs=[];
async function emit(name,zip){const bytes=await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE',compressionOptions:{level:9}});await writeFile(join(dist,name),bytes);outputs.push({file:name,bytes:bytes.length,sha256:hash(bytes)});}
const templates=new JSZip();
for(const r of routes){const p=await publicPack(r.id);templates.file(r.id+'.hwpx',Buffer.from(p.hallym.templateBase64,'base64'),{date});}
templates.file('catalog.json',await readFile('skill/hallym-kordoc/catalog.json'),{date});
templates.file('README.txt','hallym-kordoc 1.0.0-rc.1\n공개 원문 참고 재구성 13개와 공통 초안 21개입니다. 모든 세부 서식은 아닙니다. 기관 접수 승인을 뜻하지 않습니다. 문서군별 상태와 출처는 catalog.json에 있습니다. HWP 원본·개인 작성 사례는 포함하지 않습니다.\n',{date});
await emit('hallym-kordoc-templates-1.0.0-rc.1.zip',templates);
const source=new JSZip();
async function addTree(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=join(dir,e.name);if(e.isDirectory())await addTree(p);else source.file('hallym-kordoc-source/'+p.replaceAll('\\','/'),await readFile(p),{date});}}
for(const dir of ['skill','tools','tests','validation/public'])await addTree(dir);
for(const name of ['README.md','package.json','.gitignore'])source.file('hallym-kordoc-source/'+name,await readFile(name),{date});
await emit('hallym-kordoc-source-1.0.0-rc.1.zip',source);
const plugin=resolve('distribution/Achmage-Skills/Hallym-Documents');await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await cp('skill/hallym-kordoc',join(plugin,'hallym-kordoc'),{recursive:true});
const meta={name:'hallym-kordoc',version:'1.0.0-rc.1',description:'Hallym University document routing, Markdown authoring and HWPX forms. Local core release candidate.',author:{name:'laguna821'},license:'MIT',skills:['./hallym-kordoc']};
await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify(meta,null,2));
await cp('README.md',join(plugin,'README.md'));await cp('validation/public/VALIDATION.md',join(plugin,'VALIDATION.md'));
await writeFile('distribution/Achmage-Skills/marketplace-entry.json',JSON.stringify({...meta,source:'./Hallym-Documents',category:'productivity',tags:['hallym','hwpx','reports']},null,2));
const readme='검토용 저장소 변경안입니다. 아직 원격 저장소에 게시하지 않았습니다.\nHallym-Documents를 저장소 루트에 추가하고 marketplace-entry.json의 항목을 기존 .claude-plugin/marketplace.json의 plugins에 병합합니다. 기존 항목을 대체하지 않습니다.\n한컴 및 OS 활성 라우팅 완료 조건을 확인한 뒤 릴리스 상태를 결정합니다.\n';await writeFile('distribution/Achmage-Skills/README.txt',readme);
const repoZip=new JSZip();
async function repoWalk(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=join(dir,e.name);if(e.isDirectory())await repoWalk(p);else repoZip.file(relative(resolve('distribution/Achmage-Skills'),p).replaceAll('\\','/'),await readFile(p),{date});}}
await repoWalk(resolve('distribution/Achmage-Skills'));await emit('hallym-kordoc-Achmage-Skills-candidate.zip',repoZip);
await cp('validation/public/VALIDATION.md',join(dist,'VALIDATION.md'));await cp('validation/public/validation.json',join(dist,'validation.json'));
const core=JSON.parse(await readFile('dist/package-report.json'));outputs.unshift({file:'hallym-kordoc-1.0.0-rc.1.zip',bytes:core.bytes,sha256:core.sha256});
await writeFile(join(dist,'ARTIFACTS.json'),JSON.stringify(outputs,null,2));await writeFile(join(dist,'SHA256SUMS'),outputs.map(x=>x.sha256+'  '+x.file).join('\n')+'\n');console.log(JSON.stringify(outputs));
