import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {execute} from '../skill/hallym-kordoc/scripts/run.mjs';
import {routes,publicPack,routeRequest} from '../skill/hallym-kordoc/scripts/catalog.mjs';
import {hash,packHash} from '../skill/hallym-kordoc/scripts/common.mjs';
import {JSZip} from '../skill/hallym-kordoc/scripts/xml.mjs';
const root=resolve('validation/jobs/boundaries-'+Date.now());await mkdir(root,{recursive:true});process.env.HALLYM_KORDOC_HOME=join(root,'private');process.env.KORDOC_OFFLINE='1';let n=0;const out=()=>join(root,'job-'+(++n));
const basic={schemaVersion:1,mode:'compose',familyId:'report.hallym',values:{department:'합성 부서',purpose:'시험 목적'},sections:Object.fromEntries(routes.find(r=>r.id==='report.hallym').sections.map(s=>[s,'- 검증용 본문\n- 사용자 정보만 반영']))};
test('natural phrasing and hierarchy resolve without selecting unrelated funding',()=>{
 for(const [prompt,id] of [['이번 PBL 수업 운영 승인을 신청하는 서류','pbl.apply'],['글로컬 자문 받은 내용을 정리해줘','glocal.advisory'],['학부생 복학 신청서를 작성해줘','central.academic'],['대학원생의 공결 신청 문서','grad.student'],['교수법 코칭 신청서를 만들자','teaching.coaching'],['논문 번역료 지원 신청 양식으로 해줘','research.fee']])assert.equal(routeRequest({prompt}).familyId,id,prompt);
});
test('bullet report is successful and deterministic between processes',async()=>{
 const hashes=[];
 for(let i=0;i<2;i++){const p=spawnSync(process.execPath,['skill/hallym-kordoc/scripts/run.mjs'],{input:JSON.stringify({...basic,outputDir:out()}),encoding:'utf8',env:process.env});const r=JSON.parse(p.stdout);assert.equal(r.status,'success',JSON.stringify(r));hashes.push(r.files.find(f=>f.name==='document.hwpx').sha256);}
 assert.equal(hashes[0],hashes[1]);
});
test('batch creates isolated children and reports a mixed failure',async()=>{
 const r=await execute({schemaVersion:1,mode:'batch',outputDir:out(),jobs:[basic,{mode:'compose',familyId:'unknown'}]});
 assert.equal(r.status,'partial');assert.equal(r.results[0].status,'success');assert.equal(r.results[1].failure.code,'UNKNOWN_FAMILY');
});
test('private registration of actual HWPX supports named fields and new-session filling',async()=>{
 const p=await publicPack('pbl.advisory'),path=join(root,'blank.hwpx');await writeFile(path,Buffer.from(p.hallym.templateBase64,'base64'));
 const before=hash(await readFile(path));
 const r=await execute({schemaVersion:1,mode:'template-register',input:path,templateId:'my-advisory',name:'합성 자문 양식',familyId:'pbl.advisory',analysisDir:out()});
 assert.equal(r.status,'success',JSON.stringify(r));assert.equal(hash(await readFile(path)),before);
 const values=Object.fromEntries(p.hallym.recipe.fields.map((f,i)=>[f.id,'새로운 값 '+i]));
 const processResult=spawnSync(process.execPath,['skill/hallym-kordoc/scripts/run.mjs'],{input:JSON.stringify({schemaVersion:1,mode:'compose',template:r.data.hash,values,outputDir:out()}),encoding:'utf8',env:process.env});
 const result=JSON.parse(processResult.stdout);assert.equal(result.status,'success',JSON.stringify(result));assert.equal(result.templateSource,'explicit-private');assert.equal(result.validation.readback,'passed');
});
test('duplicate named fields reject registration instead of filling two people',async()=>{
 const p=await publicPack('pbl.advisory'),zip=await JSZip.loadAsync(Buffer.from(p.hallym.templateBase64,'base64'));
 const xml=await zip.file('Contents/section0.xml').async('string');zip.file('Contents/section0.xml',xml.replace('name="adviser.name"','name="responsible.name"'));
 const file=join(root,'duplicate.hwpx');await writeFile(file,await zip.generateAsync({type:'nodebuffer'}));
 const r=await execute({schemaVersion:1,mode:'template-register',input:file,templateId:'duplicate',analysisDir:out()});
 assert.equal(r.failure.code,'DUPLICATE_FIELD');
});
test('corrupt and absent input fail without changing the input',async()=>{
 const file=join(root,'corrupt.hwpx');await writeFile(file,Buffer.from('504b030400000000','hex'));const before=hash(await readFile(file));
 const r=await execute({schemaVersion:1,mode:'read',input:file,outputDir:out()});assert.equal(r.status,'failed');assert.ok(r.failure.code);
 assert.equal(hash(await readFile(file)),before);
 const absent=await execute({schemaVersion:1,mode:'read',input:join(root,'no.hwpx'),outputDir:out()});assert.equal(absent.failure.code,'FILE_NOT_FOUND');
});
test('missing extension is a clear offline failure',async()=>{
 const b=await execute({...basic,outputDir:out()});
 const child=spawnSync(process.execPath,['skill/hallym-kordoc/scripts/run.mjs'],{input:JSON.stringify({schemaVersion:1,mode:'render',input:b.files[0].path,format:'pdf',outputDir:out()}),encoding:'utf8',env:{...process.env,KORDOC_WORKBENCH_CACHE:join(root,'empty-cache'),KORDOC_OFFLINE:'1'}});
 const r=JSON.parse(child.stdout);assert.equal(r.status,'failed');assert.equal(r.failure.code,'DEPENDENCY_UNAVAILABLE_OFFLINE');
});
test('nested new output parents are created, while existing output is preserved',async()=>{
 const dest=join(root,'new-parent','nested','document');const first=await execute({...basic,outputDir:dest});assert.equal(first.status,'success');
 const next=await execute({...basic,outputDir:dest});assert.equal(next.failure.code,'OUTPUT_CONFLICT');
});
test.after(()=>console.log('BOUNDARY_EVIDENCE_DIR='+root));
