import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
import {execute} from '../skill/hallym-kordoc/scripts/run.mjs';
import {routes,publicPack,routeRequest} from '../skill/hallym-kordoc/scripts/catalog.mjs';
import {parse,toArray,extractClickHereFields} from '../skill/hallym-kordoc/scripts/engine.mjs';
import {hash,packHash} from '../skill/hallym-kordoc/scripts/common.mjs';
import {JSZip} from '../skill/hallym-kordoc/scripts/xml.mjs';
const root=resolve('validation/jobs/'+Date.now());await mkdir(root,{recursive:true});process.env.HALLYM_KORDOC_HOME=join(root,'private');process.env.KORDOC_OFFLINE='1';
const evidence=[];let n=0;
const out=()=>join(root,'job-'+(++n));
const values=r=>Object.fromEntries(r.fields.map((f,i)=>[f.id,f.id==='term'&&r.sourceTerm?r.sourceTerm:'시험값'+i+' '+f.label]));
const sections=r=>Object.fromEntries(r.sections.map(name=>[name,'합성 검증용 본문입니다. 실제 실적이나 개인정보가 아닙니다.']));
const compose=(r,more={})=>execute({schemaVersion:1,mode:'compose',familyId:r.id,values:values(r),sections:sections(r),outputDir:out(),...more});
const document=async r=>readFile(r.files.find(f=>f.name==='document.hwpx').path);
test('34 families route, compose, and retain every provided value',async()=>{
 assert.equal(routes.length,34);
 for(const r of routes){
  const selected=routeRequest({prompt:r.hints[0]+' 문서를 작성해 주세요'});
  assert.equal(selected.familyId,r.id,JSON.stringify(selected));
  const result=await compose(r);
  assert.notEqual(result.status,'failed',JSON.stringify(result.failure));
  assert.deepEqual(result.missingFields,[]);
  assert.deepEqual(result.skipped.fields,[]);
  assert.equal(result.validation.readback,'passed',JSON.stringify(result.warnings));
  assert.ok(result.files.some(f=>f.name==='preview.html'));
  const b=await document(result),p=await parse(b,{images:false});
  assert.ok(p.success);
  for(const field of r.fields)assert.ok(p.markdown.replace(/[\s\\]/g,'').includes(values(r)[field.id].replace(/[\s\\]/g,'')),r.id+' '+field.id);
  evidence.push({familyId:r.id,selection:selected.familyId,status:result.status,templateStatus:result.templateStatus,sha256:hash(b),ms:result.elapsedMs,readback:result.validation.readback,warnings:result.warnings,output:result.files.find(f=>f.name==='document.hwpx').path});
 }
 await writeFile(join(root,'matrix.json'),JSON.stringify(evidence,null,2));
});
test('ambiguous meeting asks; funding and academic level stay separate',()=>{
 assert.equal(routeRequest({prompt:'회의록을 만들어줘'}).needsClarification,true);
 assert.equal(routeRequest({prompt:'글로컬 회의비 사용 회의록'}).familyId,'glocal.meeting');
 assert.equal(routeRequest({prompt:'RISE 프로그램 운영계획서'}).familyId,'rise.program');
 assert.equal(routeRequest({prompt:'대학원 복학 신청'}).familyId,'grad.student');
 assert.equal(routeRequest({prompt:'학부 복학 신청'}).familyId,'central.academic');
 assert.equal(routeRequest({prompt:'PBL RISE 회의록'}).needsClarification,true);
});
test('new term and unsupported variant are explicit drafts',async()=>{
 const a=await execute({schemaVersion:1,mode:'resolve',prompt:'PBL 회의록',context:{term:'2027-1'}});
 assert.equal(a.templateStatus,'common-draft');
 const b=await execute({schemaVersion:1,mode:'resolve',prompt:'학부 자퇴 신청'});
 assert.equal(b.templateStatus,'common-draft');assert.ok(!b.recipe.notes.some(x=>x.includes('복학 신청')));
});
test('fixed fields distinguish names, multiline content, and reject unknown keys',async()=>{
 const r=routes.find(r=>r.id==='pbl.advisory'),v=values(r);v['responsible.name']='책임자시험';v['adviser.name']='자문자시험';v.content='첫 줄\n둘째 줄 <태그> & 내용';
 const result=await compose(r,{values:{...v,unknown:'반영되지 않을 값'}});
 assert.equal(result.status,'partial');assert.deepEqual(result.skipped.fields,['unknown']);
 const fields=await extractClickHereFields(toArray(await document(result)));
 assert.equal(fields.find(x=>x.name==='responsible.name').value,'책임자시험');
 assert.equal(fields.find(x=>x.name==='adviser.name').value,'자문자시험');
});
test('missing required facts remain partial; output collision preserves original',async()=>{
 const r=routes[0],dest=out(),a=await compose(r,{values:{},outputDir:dest});
 assert.equal(a.status,'partial');assert.ok(a.missingFields.length);
 const before=hash(await document(a)),b=await compose(r,{outputDir:dest});
 assert.equal(b.failure.code,'OUTPUT_CONFLICT');assert.equal(hash(await document(a)),before);
});
test('variable rows, long text and image roundtrip; wrong column count fails',async()=>{
 const r=routes.find(x=>x.id==='grad.ta');
 const image=join(root,'image.png');await writeFile(image,Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a9XkAAAAASUVORK5CYII=','base64'));
 const a=await compose(r,{sections:{'업무 기록':'수업 준비와 피드백. '.repeat(100)+'\n\n![자료](image.png)'},tables:{'업무 기록':Array.from({length:19},(_,i)=>['일자'+i,'실제 활동을 입력하는 열','과목','장소','시간'])},images:{'image.png':image}});
 assert.notEqual(a.status,'failed',JSON.stringify(a.failure));const p=await parse(await document(a));assert.ok(p.markdown.includes('일자18'));assert.ok(p.images?.length);
 const bad=await compose(r,{tables:{'업무 기록':[['한 칸']]}});assert.equal(bad.failure.code,'TABLE_RULE_MISMATCH');
 const missing=await compose(r,{sections:{'업무 기록':'![없는 이미지](missing.png)'}});assert.equal(missing.failure.code,'MISSING_ASSET');
});
test('fixed bytes deterministic across fresh processes',async()=>{
 const r=routes.find(x=>x.id==='pbl.advisory'),request={schemaVersion:1,mode:'compose',familyId:r.id,values:values(r)};
 const hashes=[];
 for(let i=0;i<2;i++){const result=spawnSync(process.execPath,['skill/hallym-kordoc/scripts/run.mjs'],{input:JSON.stringify({...request,outputDir:out()}),encoding:'utf8',env:process.env});assert.ok([0,2].includes(result.status),result.stdout+result.stderr);hashes.push(hash(await document(JSON.parse(result.stdout))));}
 assert.equal(hashes[0],hashes[1]);
});
test('private export/import persists, deduplicates, and bindings are scoped',async()=>{
 const r=routes.find(x=>x.id==='pbl.advisory'),e=await execute({schemaVersion:1,mode:'template-export',familyId:r.id,outputDir:out()});
 const spec={schemaVersion:1,mode:'template-register',template:e.files[0].path,binding:{familyId:r.id,context:{term:'2026-2'}}};
 const a=await execute(spec),b=await execute(spec);assert.equal(a.data.state,'registered');assert.equal(b.data.state,'already-exists');
 const result=await compose(r,{template:a.data.hash});assert.notEqual(result.status,'failed');
 const unrelated=await execute({schemaVersion:1,mode:'resolve',familyId:'report.hallym',context:{term:'2026-2'}});assert.notEqual(unrelated.templateHash,a.data.hash);
 const changed=JSON.parse(await readFile(e.files[0].path,'utf8'));changed.version='1.0.1';changed.contentHash=packHash(changed);const path=join(root,'variant.json');await writeFile(path,JSON.stringify(changed));
 const v=await execute({...spec,template:path});assert.notEqual(v.data.hash,a.data.hash);assert.equal((await execute({schemaVersion:1,mode:'library-list'})).data.length,2);
 const child=spawnSync(process.execPath,['skill/hallym-kordoc/scripts/run.mjs'],{input:JSON.stringify({schemaVersion:1,mode:'library-list'}),encoding:'utf8',env:process.env});assert.equal(JSON.parse(child.stdout).data.length,2);
});
test('tampered pack, damaged input, and HWP mutation fail clearly',async()=>{
 const pack=await publicPack('pbl.advisory');pack.name='tampered';const path=join(root,'bad.json');await writeFile(path,JSON.stringify(pack));
 assert.equal((await execute({schemaVersion:1,mode:'compose',template:path,outputDir:out()})).failure.code,'INVALID_TEMPLATE_PACK');
 const damaged=join(root,'damaged.hwpx');await writeFile(damaged,'broken');
 assert.equal((await execute({schemaVersion:1,mode:'template-register',input:damaged,templateId:'bad',analysisDir:out()})).failure.code,'HWPX_REQUIRED');
 assert.equal((await execute({schemaVersion:1,mode:'patch',input:damaged,markdown:'x'})).failure.code,'HWP_REFERENCE_ONLY');
 assert.equal((await execute({schemaVersion:1,mode:'compose',familyId:'report.hallym',outputName:'bad.hwp'})).failure.code,'HWP_OUTPUT_FORBIDDEN');
});
test.after(()=>console.log('EVIDENCE_DIR='+root));
