import {readFile,writeFile,readdir} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
import {runRequest} from '../staging/lean-0.2.0/kordoc-workbench/scripts/run.mjs';
const results=[];
async function visit(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=join(dir,e.name);if(e.isDirectory())await visit(p);else if(e.name.endsWith('.hwpx')){const bytes=await readFile(p);const r=await runRequest({schemaVersion:1,mode:'validate',input:resolve(p),outputDir:resolve('.cache/web-verify-'+results.length+'-'+Date.now())});results.push({input:p,sha256:createHash('sha256').update(bytes).digest('hex'),result:r});}}}
await visit('validation/web');await writeFile('validation/web-download-verification.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results.map(x=>({input:x.input,status:x.result.status,sha256:x.sha256}))));if(results.some(x=>x.result.status==='failed'))process.exitCode=1;
