import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {hashPack,validatePack} from '../skill/kordoc-workbench/scripts/templates.mjs';
import {ENGINE,sha256,stable} from '../skill/kordoc-workbench/scripts/common.mjs';
const settingsPath=process.argv[2];if(!settingsPath)throw new Error('Pass the exact HanMark data.json to read; it is never modified.');
const settings=JSON.parse(await readFile(settingsPath,'utf8')),library=settings.hanmarkTemplateLibrary;
if(!library)throw new Error('No named template library present');
const out=resolve('private-templates');await mkdir(out,{recursive:true});const index=[];
for(const [kind,records]of [['general',library.customTemplates||{}],['official',library.gongmunTemplates||{}]]){
 for(const r of Object.values(records)){
  const source=stable(r),sourceHash=sha256(source),id='personal-'+sourceHash.slice(0,16);
  const pack={kind:'kordoc-template-pack',schemaVersion:1,id,version:'1.0.0',name:r.name,
   source:{name:'saved-hanmark-template.json',sha256:sourceHash,format:'hanmark-template-library-v'+library.schemaVersion},
   engine:ENGINE,markdownSkeleton:'# '+r.name+'\n\n{{본문}}\n',fields:[{name:'본문',type:'text',required:true}],assets:[],tableRules:[],
   evidence:[{authority:'saved-hanmark-settings',engineVersion:'4.15.7',librarySchemaVersion:library.schemaVersion,recordId:r.id}],
   limitations:['Original reference document is unavailable in this export; source hash identifies the preserved saved style record.','Visual and fresh-session review pending.'],
   validation:{structural:'pending',visual:'pending',hanmark:{engineVersion:'4.15.7',status:'pending'}}
  };
  if(kind==='general'){
   if(r.documentStyle)pack.documentStyle=structuredClone(r.documentStyle);
   if(r.tableStyle)pack.tableProfile=structuredClone(r.tableStyle);
   if(r.fontSubstitutions&&pack.documentStyle){
    for(const role of Object.values(pack.documentStyle.roles||{})){
     const family=role?.character?.fontFamily;
     if(r.fontSubstitutions[family])role.character.fontFamily=r.fontSubstitutions[family];
    }pack.evidence.push({authority:'saved-hanmark-settings',fontSubstitutions:r.fontSubstitutions});
   }
  }else{pack.gongmun={...r.options,preset:r.preset||library.activeGongmunPreset||'official'};if(r.tableStyle)pack.tableProfile=r.tableStyle;}
  pack.contentHash=hashPack(pack);validatePack(pack);
  const dir=join(out,id);await mkdir(dir,{recursive:true});
  await writeFile(join(dir,'source-record.json'),JSON.stringify(r,null,2),{flag:'wx'});
  const file=join(dir,'template.kordoc-template.json');await writeFile(file,JSON.stringify(pack,null,2),{flag:'wx'});
  index.push({id,kind,path:file,contentHash:pack.contentHash});
 }
}
await writeFile(join(out,'INDEX.json'),JSON.stringify({private:true,excludedFromPublicPackages:true,engine:ENGINE,packs:index},null,2),{flag:'wx'});
console.log(JSON.stringify({private:true,packs:index.length,byKind:index.reduce((a,x)=>(a[x.kind]=(a[x.kind]||0)+1,a),{}),index:join(out,'INDEX.json')}));

