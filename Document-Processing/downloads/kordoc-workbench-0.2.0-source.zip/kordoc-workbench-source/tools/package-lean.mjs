import { build } from 'esbuild';
import { readFile,writeFile,mkdir,cp,readdir,stat,rename } from 'node:fs/promises';
import { resolve,join,dirname,relative } from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
const out=resolve('staging/lean-0.2.0/kordoc-workbench');
try { await stat(out); await rename(out,out+'.previous-'+Date.now()); } catch(e) { if(e.code!=='ENOENT')throw e; }
await mkdir(join(out,'scripts'),{recursive:true});
const externals=['sharp','onnxruntime-node','onnxruntime-web','@hyzyla/pdfium','@huggingface/transformers','puppeteer-core','pdfjs-dist'];
const result=await build({entryPoints:['skill/kordoc-workbench/scripts/run.mjs'],outdir:join(out,'scripts'),outExtension:{'.js':'.mjs'},splitting:true,bundle:true,write:false,platform:'node',format:'esm',target:'node20',external:[...externals,'./extensions.mjs'],banner:{js:'import {createRequire as __coreCreateRequire} from "node:module"; const require=__coreCreateRequire(import.meta.url); import {extensionUrl as __extensionUrl,extensionPath as __extensionPath} from "./extensions.mjs";'},plugins:[{name:'inline-cfb',setup(b){b.onLoad({filter:/kordoc[\\/]dist[\\/]index\.js$/},async a=>({contents:'import * as __inlineCFB from "cfb";\n'+(await readFile(a.path,'utf8')).replace(/require\d*\(["']cfb["']\)/g,'__inlineCFB'),loader:'js'}));}}]});
for(const output of result.outputFiles){
 let code=output.text.replace(/import\("((?:pdfjs-dist|sharp|onnxruntime-node|onnxruntime-web|@hyzyla\/pdfium|@huggingface\/transformers|puppeteer-core)[^"]*)"\)/g,(_,name)=>'import(__extensionUrl('+JSON.stringify(name)+'))');
 code=code.replace(/import \{([^}]+)\} from "(pdfjs-dist[^"]+)";/g,(_,names,name)=>'const {'+names.replace(/\s+as\s+/g,':')+'} = await import(__extensionUrl('+JSON.stringify(name)+'));');
 code=code.replace(/import \* as (\w+) from "(pdfjs-dist[^"]+)";/g,(_,binding,name)=>'const '+binding+' = await import(__extensionUrl('+JSON.stringify(name)+'));');
 code=code.replace(/\w+\.resolve\("pdfjs-dist\/package.json"\)/g,'__extensionPath("pdfjs-dist/package.json")');
 await writeFile(output.path,code);
}
await build({entryPoints:['skill/kordoc-workbench/scripts/extensions.mjs'],bundle:true,platform:'node',format:'esm',target:'node20',outfile:join(out,'scripts/extensions.mjs')});
for(const file of ['launch.py','install.mjs'])await cp('skill/kordoc-workbench/scripts/'+file,join(out,'scripts',file));
for(const file of ['setup.ps1','setup.sh','ASSETS.json'])await cp('skill/kordoc-workbench/'+file,join(out,file));
await cp('skill/kordoc-workbench/references',join(out,'references'),{recursive:true});
await cp('skill/kordoc-workbench/SKILL.md',join(out,'SKILL.md'));
await cp('node_modules/kordoc/templates',join(out,'templates'),{recursive:true});
await cp('node_modules/kordoc/dist/index.d.ts',join(out,'references/engine-api.d.ts'));
await cp('LICENSE',join(out,'LICENSE-WORKBENCH'));
await cp('node_modules/kordoc/NOTICE',join(out,'NOTICE-KORDOC'));
await cp('node_modules/kordoc/THIRD_PARTY',join(out,'THIRD_PARTY'),{recursive:true});
const lock=JSON.parse(await readFile('package-lock.json','utf8'));
const groups={raster:['sharp'],pdf:['pdfjs-dist','@hyzyla/pdfium'],ocr:['onnxruntime-node'],formula:['@huggingface/transformers'],print:['puppeteer-core']};
for(const [group,names] of Object.entries(groups)){
 const dependencies=Object.fromEntries(names.map(n=>[n,lock.packages['node_modules/'+n].version]));
 const pkg={name:'kordoc-workbench-'+group,version:'0.2.0',private:true,dependencies};
 const packages={'':pkg},queue=names.map(n=>'node_modules/'+n);
 function findDep(from,name){let dir=from;while(dir){const key=dir+'/node_modules/'+name;if(lock.packages[key])return key;const i=dir.lastIndexOf('/node_modules/');dir=i<0?'':dir.slice(0,i);}return 'node_modules/'+name;}
 while(queue.length){const key=queue.pop();if(packages[key])continue;const entry=lock.packages[key];if(!entry)throw Error('Unresolved lock entry '+key);const clean={...entry};delete clean.dev;packages[key]=clean;for(const name of Object.keys({...entry.dependencies,...entry.optionalDependencies}))queue.push(findDep(key,name));}
 const dest=join(out,'extensions',group);await mkdir(dest,{recursive:true});
 await writeFile(join(dest,'package.json'),JSON.stringify(pkg,null,2));await writeFile(join(dest,'package-lock.json'),JSON.stringify({name:pkg.name,version:pkg.version,lockfileVersion:3,requires:true,packages},null,2));
 await cp(dest,resolve('skill/kordoc-workbench/extensions',group),{recursive:true});
}
const upstream=process.argv[2];if(!upstream)throw Error('Pinned upstream source path required for model preparation bundle');
await build({stdin:{contents:`export async function prepareModels(formula){await (await import(${JSON.stringify(join(upstream,'src/ocr/models.ts'))})).ensureOcrModels();if(formula)await (await import(${JSON.stringify(join(upstream,'src/pdf/formula/models.ts'))})).ensureFormulaModels();}`,resolveDir:process.cwd()},bundle:true,platform:'node',format:'esm',target:'node20',outfile:join(out,'scripts/model-prepare.mjs')});
await cp(join(out,'scripts/model-prepare.mjs'),'skill/kordoc-workbench/scripts/model-prepare.mjs');
const licenses=[],licenseTexts=[];
for(const [key,pkg] of Object.entries(lock.packages)){if(!key)continue;licenses.push({name:key.replace(/^.*node_modules\//,''),version:pkg.version,license:pkg.license,integrity:pkg.integrity});try{for(const e of await readdir(key,{withFileTypes:true})){if(e.isFile()&&/^(LICENSE|LICENCE|COPYING|NOTICE)(\.|$)/i.test(e.name)){licenseTexts.push('===== '+key+' / '+e.name+' =====\n'+await readFile(join(key,e.name),'utf8'));}}}catch(e){if(e.code!=='ENOENT')throw e;}}
await writeFile(join(out,'THIRD-PARTY-LICENSES.txt'),licenseTexts.join('\n\n'));
await writeFile(join(out,'THIRD-PARTY-PACKAGES.json'),JSON.stringify(licenses,null,2));
const liveChunks=new Set(result.outputFiles.map(f=>resolve(f.path)));
const files=[];async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=join(dir,e.name);if(e.isDirectory())await walk(p);else if(!['PACKAGE-MANIFEST.json','THIRD-PARTY-PACKAGES.json'].includes(relative(out,p))){if(dirname(p)===join(out,'scripts')&&e.name.endsWith('.mjs')&&!['extensions.mjs','model-prepare.mjs','install.mjs'].includes(e.name)&&!liveChunks.has(resolve(p)))continue;const bytes=await readFile(p);files.push({path:relative(out,p).replaceAll('\\','/'),bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}}}await walk(out);
await writeFile(join(out,'PACKAGE-MANIFEST.json'),JSON.stringify({schemaVersion:1,name:'kordoc-workbench',version:'0.2.0',profile:'core',engine:{version:'4.18.13',commit:'969526345dde7d6acd2f2bfd3c8e592069333355'},networkRequiredAtUse:false,extensionsMayDownload:true,files},null,2));
const zip=resolve('packages/kordoc-workbench-0.2.0-core.zip');const p=spawnSync('python',['tools/package.py',out,zip],{stdio:'inherit'});if(p.status)throw Error('Packaging failed');if((await stat(zip)).size>10000000)throw Error('Core ZIP exceeds 10 MB release limit');

