#!/usr/bin/env python3
"""Verify a release archive, install once and link supported local skill directories."""
import argparse, hashlib, json, os, platform, subprocess, sys, zipfile
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument("archive",type=Path)
p.add_argument("--destination",type=Path)
p.add_argument("--codex",action="store_true")
p.add_argument("--claude",action="store_true")
p.add_argument("--update",action="store_true",help="Verify existing release manifest and preserve changed files before updating")
a=p.parse_args()
key={"Windows":"win32","Linux":"linux","Darwin":"darwin"}[platform.system()]
arch={"AMD64":"x64","x86_64":"x64","aarch64":"arm64","arm64":"arm64"}[platform.machine()]
target=(a.destination or Path.home()/".kordoc-workbench"/"releases"/"0.1.0"/(key+"-"+arch)).resolve()
try:
 with zipfile.ZipFile(a.archive) as z:
  prefix="kordoc-workbench/"
  entries=z.namelist()
  if len(entries)!=len(set(entries)):raise ValueError("DUPLICATE_ARCHIVE_ENTRY")
  for name in entries:
   parts=Path(name).parts
   if not name.startswith(prefix) or ".." in parts or "\\" in name:raise ValueError("UNSAFE_ARCHIVE_PATH")
  manifest=json.loads(z.read(prefix+"PACKAGE-MANIFEST.json"))
  if manifest["platform"]!=key or manifest["arch"]!=arch:raise ValueError("RUNTIME_PLATFORM_MISMATCH")
  if manifest["engine"]["version"]!="4.18.13":raise ValueError("ENGINE_VERSION_MISMATCH")
  expected={prefix+f["path"]:f for f in manifest["files"]}
  for name,info in expected.items():
   data=z.read(name)
   if len(data)!=info["bytes"] or hashlib.sha256(data).hexdigest()!=info["sha256"]:raise ValueError("PACKAGE_HASH_MISMATCH: "+name)
  extras=set(entries)-set(expected)-{prefix+"PACKAGE-MANIFEST.json",prefix+"THIRD-PARTY-PACKAGES.json"}
  if extras:raise ValueError("UNMANIFESTED_FILES")
  if target.exists():
   old=json.loads((target/"PACKAGE-MANIFEST.json").read_text(encoding="utf8"))
   if old["name"]!="kordoc-workbench" or old["platform"]!=key or old["arch"]!=arch:raise ValueError("INSTALL_CONFLICT")
   for info in old["files"]:
    file=target/info["path"]
    if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest()!=info["sha256"]:raise ValueError("LOCAL_CHANGES_PRESERVED: "+str(file))
   changed=[]
   for info in manifest["files"]:
    file=target/info["path"]
    if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest()!=info["sha256"]:changed.append(info)
   if changed and not a.update:raise ValueError("INSTALL_CONFLICT: verified update requires --update")
   if changed:
    archive_hash=hashlib.sha256(a.archive.read_bytes()).hexdigest()
    backup=target.parent/("source-backup-"+archive_hash[:12])
    for info in changed:
     file=target/info["path"]
     if file.exists():
      saved=backup/info["path"];saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(file.read_bytes())
     file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(z.read(prefix+info["path"]))
    for meta in ["PACKAGE-MANIFEST.json","THIRD-PARTY-PACKAGES.json"]:(target/meta).write_bytes(z.read(prefix+meta))
  else:
   stage=target.with_name(target.name+".install-"+str(os.getpid()))
   stage.mkdir(parents=True,exist_ok=False)
   for name in entries:
    if name.endswith("/"):continue
    file=stage/name[len(prefix):]
    file.parent.mkdir(parents=True,exist_ok=True)
    file.write_bytes(z.read(name))
    if key!="win32" and (name.endswith("/bin/node") or "chrome-headless-shell" in name and not Path(name).suffix):
     file.chmod(file.stat().st_mode|0o111)
   stage.rename(target)
 links=[]
 roots=[]
 if a.codex:roots.append(Path(os.environ.get("CODEX_HOME",Path.home()/".codex"))/"skills")
 if a.claude:roots.append(Path.home()/".claude"/"skills")
 for root in roots:
  root.mkdir(parents=True,exist_ok=True)
  link=root/"kordoc-workbench"
  if link.exists():
   if link.resolve()!=target:raise ValueError("SKILL_INSTALL_CONFLICT: "+str(link))
  elif key=="win32":
   quote=lambda x:"'"+str(x).replace("'","''")+"'"
   script="New-Item -ItemType Junction -Path "+quote(link)+" -Target "+quote(target)+" -ErrorAction Stop | Out-Null"
   subprocess.run(["powershell","-NoProfile","-Command",script],check=True,capture_output=True,text=True)
  else:link.symlink_to(target,target_is_directory=True)
  links.append(str(link))
 receipt={"status":"installed","release":str(target),"engine":manifest["engine"],"skillLinks":links,
  "archiveSha256":hashlib.sha256(a.archive.read_bytes()).hexdigest(),"environmentCertification":"See validation records; installation is not fresh-session proof"}
 (target.parent/"installation.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding="utf8")
 print(json.dumps(receipt,ensure_ascii=False))
except Exception as e:
 print(json.dumps({"status":"failed","code":"INSTALL_FAILED","message":str(e),"originalSettingsPreserved":True},ensure_ascii=False))
 sys.exit(1)
