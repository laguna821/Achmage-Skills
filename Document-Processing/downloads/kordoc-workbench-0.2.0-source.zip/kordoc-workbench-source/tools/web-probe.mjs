import { mkdir,writeFile,readFile } from 'node:fs/promises';
import { build } from 'esbuild';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import JSZip from 'jszip';
const root=resolve('probes/kordoc-web-probe');await mkdir(root+'/scripts',{recursive:true});
await writeFile(root+'/SKILL.md',`---
name: kordoc-web-probe
description: Verify bundled kordoc HWPX generation in a web session, without network or an external executor.
---
This is a synthetic runtime probe, not the full workbench. Run python scripts/probe.py. Report the JSON result and provide the generated HWPX and SVG. No package/model downloads. Native OCR/PDF features are not included in this probe. If bundled Node cannot execute, report the actual error; do not substitute a remote executor.
`);
const entry=`import * as k from 'kordoc';import fs from 'node:fs';import path from 'node:path';
const out=process.argv[2]||'/mnt/data/kordoc-probe';fs.mkdirSync(out,{recursive:true});
const bytes=await k.markdownToHwpx('# 독립 웹 실행 검증\\n\\n한국어 HWPX 생성 성공');
fs.writeFileSync(path.join(out,'probe.hwpx'),Buffer.from(bytes));
const parsed=await k.parse(Buffer.from(bytes));const validated=await k.validateHwpx(bytes);
const preview=await k.renderDocument(Buffer.from(bytes),{format:'svg'});
for(const [i,a]of preview.assets.entries())fs.writeFileSync(path.join(out,'preview-'+(i+1)+'.svg'),a.data);
console.log(JSON.stringify({node:process.version,platform:process.platform,arch:process.arch,engine:k.VERSION,parseSuccess:parsed.success,markdown:parsed.markdown,valid:validated.ok,files:fs.readdirSync(out),offline:true}));
`;
await build({stdin:{contents:entry,resolveDir:process.cwd(),sourcefile:'web-probe.mjs'},outfile:root+'/scripts/probe.mjs',bundle:true,format:'esm',platform:'node',target:'node20',external:['sharp','onnxruntime-node','onnxruntime-web','@hyzyla/pdfium','@huggingface/transformers','puppeteer-core'],banner:{js:"import {createRequire as __wkCreateRequire} from 'node:module'; const require=__wkCreateRequire(import.meta.url);"},plugins:[{name:'bundle-cfb',setup(build){build.onLoad({filter:/kordoc[\\/]dist[\\/]index\.js$/},async(args)=>({contents:"import __wkCFB from 'cfb';\n"+(await readFile(args.path,'utf8')).replace(/\brequire\d*\([\"']cfb[\"']\)/g,'__wkCFB'),loader:'js'}));}}]});
await writeFile(root+'/scripts/probe.py',`import json, lzma, os, pathlib, subprocess, sys, tempfile
root = pathlib.Path(__file__).resolve().parent.parent
out = pathlib.Path("/mnt/data/kordoc-probe") if pathlib.Path("/mnt/data").exists() else pathlib.Path(tempfile.mkdtemp(prefix="kordoc-probe-"))
out.mkdir(parents=True, exist_ok=True)
node = out / "node"
try:
    with lzma.open(root / "node-linux-x64.xz", "rb") as src, node.open("wb") as dest:
        while chunk := src.read(1024*1024): dest.write(chunk)
    node.chmod(0o755)
    p = subprocess.run([str(node), str(root/"scripts/probe.mjs"), str(out)], capture_output=True, text=True, env={**os.environ, "KORDOC_OFFLINE":"1", "ORT_DISABLE_TELEMETRY":"1"}, timeout=120)
    print(p.stdout)
    if p.stderr: print(p.stderr, file=sys.stderr)
    sys.exit(p.returncode)
except Exception as e:
    print(json.dumps({"success":False,"error":str(e),"platform":sys.platform}))
    sys.exit(1)
`);
const compression=spawnSync('python',['-c',"import lzma,sys; from pathlib import Path; p=Path(sys.argv[1]); out=Path(sys.argv[2]); out.exists() or out.write_bytes(lzma.compress(p.read_bytes(),preset=9)); print(out.stat().st_size)",resolve('skill/kordoc-workbench/runtime/linux-x64/bin/node'),root+'/node-linux-x64.xz'],{encoding:'utf8'});
if(compression.status)throw new Error(compression.stderr);
await writeFile(root+'/NODE-LICENSE',await readFile('skill/kordoc-workbench/runtime/linux-x64/LICENSE'));
await writeFile(root+'/KORDOC-LICENSE',await readFile('node_modules/kordoc/LICENSE'));
const zip=new JSZip();for(const f of ['SKILL.md','scripts/probe.py','scripts/probe.mjs','node-linux-x64.xz','NODE-LICENSE','KORDOC-LICENSE'])zip.file('kordoc-web-probe/'+f,await readFile(root+'/'+f));
await mkdir('packages',{recursive:true});const bytes=await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE',compressionOptions:{level:9}});
await writeFile('packages/kordoc-web-probe.zip',bytes);
console.log(JSON.stringify({path:resolve('packages/kordoc-web-probe.zip'),bytes:bytes.length,underChatgptLimit:bytes.length<25*1024*1024}));
