#!/usr/bin/env python3
"""Print optional offline kordoc MCP config; never edit an application's settings."""
import argparse, json, platform
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--skill', type=Path, required=True)
a = p.parse_args()
root = a.skill.resolve()
key = {'Windows': 'win32', 'Linux': 'linux', 'Darwin': 'darwin'}[platform.system()]
arch = {'AMD64': 'x64', 'x86_64': 'x64', 'aarch64': 'arm64', 'arm64': 'arm64'}[platform.machine()]
node = root / 'runtime' / (key + '-' + arch) / ('node.exe' if key == 'win32' else 'bin/node')
cli = root / 'node_modules/kordoc/dist/cli.js'
if not node.is_file() or not cli.is_file():
    raise SystemExit('Verified installed runtime required')
print(json.dumps({'mcpServers': {'kordoc-workbench': {
    'command': str(node), 'args': [str(cli), 'mcp'],
    'env': {'KORDOC_OFFLINE': '1', 'ORT_DISABLE_TELEMETRY': '1',
            'KORDOC_MODEL_CACHE': str(root / 'runtime/models'),
            'FONTCONFIG_FILE': str(root / 'runtime/fonts/fonts.conf')}
}}}, ensure_ascii=False, indent=2))
