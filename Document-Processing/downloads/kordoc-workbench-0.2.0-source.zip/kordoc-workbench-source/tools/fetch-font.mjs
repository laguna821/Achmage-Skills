import { mkdir,writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
const root=resolve('skill/kordoc-workbench/runtime/fonts');await mkdir(root,{recursive:true});
const base='https://raw.githubusercontent.com/notofonts/noto-cjk/main/';
const url=base+'Sans/Variable/TTF/Subset/NotoSansKR-VF.ttf';
for(const [name,source]of [['NotoSansKR-VF.ttf',url],['LICENSE-OFL.txt',base+'Sans/LICENSE']]){
 const r=await fetch(source);if(!r.ok)throw new Error(source+' '+r.status);const bytes=Buffer.from(await r.arrayBuffer());await writeFile(resolve(root,name),bytes);
 if(name.endsWith('.ttf'))await writeFile(resolve(root,'ORIGIN.json'),JSON.stringify({name:'Noto Sans KR',license:'OFL-1.1',source,sha256:createHash('sha256').update(bytes).digest('hex')},null,2));
}
await writeFile(resolve(root,'fonts.conf'),'<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd"><fontconfig><dir prefix="relative">.</dir><cachedir prefix="xdg">fontconfig</cachedir><alias><family>sans-serif</family><prefer><family>Noto Sans KR</family></prefer></alias></fontconfig>');
console.log('Noto Sans KR font bundled');
