#!/usr/bin/env python3
"""Export source, preview and private packs separately; no publishing or installs."""
import argparse, hashlib, json, zipfile
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--hanmark',type=Path,required=True)
p.add_argument('--research-source',required=True)
a=p.parse_args()
root=Path(__file__).resolve().parent.parent
out=root/'packages';out.mkdir(exist_ok=True)
engine={'version':'4.18.13','commit':'969526345dde7d6acd2f2bfd3c8e592069333355'}

def info(path,kind,status):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while b:=f.read(1024*1024):h.update(b)
    return {'path':path.relative_to(root).as_posix(),'kind':kind,'status':status,'bytes':path.stat().st_size,'sha256':h.hexdigest()}

def archive(path,files):
    names=[name for name,_ in files]
    if len(names)!=len(set(names)):raise ValueError('Duplicate ZIP name')
    temporary=path.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,file in sorted(files):
            if '..' in Path(name).parts or name.startswith('/'):raise ValueError('Unsafe ZIP name')
            item=zipfile.ZipInfo(name,(1980,1,1,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o644<<16
            z.writestr(item,file.read_bytes())
    with zipfile.ZipFile(temporary) as z:
        if z.testzip():raise ValueError('ZIP CRC failed')
    temporary.replace(path)

preview=out/'hanmark-templatepack-receiver-preview.zip'
h=a.hanmark.resolve()
archive(preview,[('hanmark/'+n,h/n) for n in ['main.js','manifest.json','styles.css','TEMPLATEPACK-RECEIVER.md','LICENSE']])
private=root/'private-templates'
private_zip=out/'kordoc-personal-template-packs.private.zip'
if private.is_dir():
    archive(private_zip,[('private-templates/'+f.relative_to(private).as_posix(),f) for f in private.rglob('*') if f.is_file()])
    (out/'PRIVATE-ARTIFACTS.json').write_text(json.dumps({'publicDistribution':False,'files':[info(private_zip,'personal-template-packs','local-private-only')]},ensure_ascii=False,indent=2),encoding='utf-8')

files=[]
for name,kind,status in [
    ('kordoc-workbench-0.1.0-win32-x64.zip','offline-runtime','windows-local-beta'),
    ('kordoc-workbench-0.1.0-linux-x64.zip','offline-runtime','packaged-not-native-certified'),
    ('kordoc-web-session-probe.zip','web-core-probe','core-only-not-full-skill'),
    ('hanmark-templatepack-receiver.patch','hanmark-source-change','unreleased-review'),
    ('hanmark-templatepack-receiver-preview.zip','hanmark-preview-build','unreleased-not-live-e2e')]:
    files.append(info(out/name,kind,status))
manifest={'schemaVersion':1,'engine':engine,'researchSource':a.research_source,
          'completion':'local-beta; full-v1-not-complete','sourceZipSelfHash':'listed in the external ARTIFACTS.json after export','files':files}
meta=out/'ARTIFACTS.json';meta.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
sources=[]
for name in ['README.md','IMPLEMENTATION-STATUS.md','LICENSE','.gitignore','package.json','package-lock.json']:
    sources.append(('kordoc-workbench-source/'+name,root/name))
for directory in ['skill/kordoc-workbench','tests','tools']:
    for f in (root/directory).rglob('*'):
        rel=f.relative_to(root)
        if f.is_file() and not {'runtime','runtime-fonts','node_modules','__pycache__'}.intersection(rel.parts):
            sources.append(('kordoc-workbench-source/'+rel.as_posix(),f))
for name in ['validation/REPORT.md','validation/claude-web-probe.png','validation/chatgpt-web-probe.png','validation/claude-full-upload-limit.png','packages/ARTIFACTS.json','packages/hanmark-templatepack-receiver.patch']:
    sources.append(('kordoc-workbench-source/'+name,root/name))
source_zip=out/'kordoc-workbench-0.1.0-source.zip';archive(source_zip,sources)
manifest['files'].append(info(source_zip,'common-source','reviewable-source'))
meta.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'sourceFiles':len(sources),'artifacts':manifest['files'],'privateArchiveExported':private_zip.exists()},ensure_ascii=False))
