import { readFile,writeFile,mkdir,cp,readdir,stat } from 'node:fs/promises';
import { createReadStream,createWriteStream } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve,join,relative } from 'node:path';
import { spawnSync } from 'node:child_process';
import { pipeline } from 'node:stream/promises';
import JSZip from 'jszip';
const platform=process.argv[2]||process.platform,arch=process.argv[3]||process.arch;
if(!['win32','linux','darwin'].includes(platform)||!['x64','arm64'].includes(arch))throw new Error('Unsupported platform');
const target=resolve('staging/'+platform+'-'+arch),skill=join(target,'kordoc-workbench');
const refresh=process.argv.includes('--refresh');
let stageExists=true;try{await stat(target);}catch(e){if(e.code!=='ENOENT')throw e;stageExists=false;}
if(refresh&&!stageExists)throw new Error('--refresh requires existing generated staging; omit --refresh for a full build.');
if(stageExists&&!refresh)throw new Error('Staging exists; inspect and use --refresh for this generated staging.');
await mkdir(skill,{recursive:true});
await cp('LICENSE',join(skill,'LICENSE-WORKBENCH'));
await cp('skill/kordoc-workbench',skill,{recursive:true,filter:p=>!p.includes('/runtime')&&!p.includes('\\runtime')&&!p.endsWith('.tmp')});
const runtime=resolve('skill/kordoc-workbench/runtime'),outRuntime=join(skill,'runtime');
await mkdir(outRuntime,{recursive:true});
for(const name of [platform+'-'+arch,'chromium-'+platform+'-'+arch,'models','fonts','runtime-'+platform+'-'+arch+'.json'])
 await cp(join(runtime,name),join(outRuntime,name),{recursive:true});
const pkg=JSON.parse(await readFile('package.json','utf8'));delete pkg.devDependencies;delete pkg.scripts;
await writeFile(join(skill,'package.json'),JSON.stringify(pkg,null,2));
await cp('package-lock.json',join(skill,'package-lock.json'));
const npm=refresh?{status:0}:spawnSync(process.platform==='win32'?'npm.cmd':'npm',['ci','--ignore-scripts','--omit=dev','--os='+platform,'--cpu='+arch,'--no-audit','--no-fund'],{cwd:skill,stdio:'inherit',shell:process.platform==='win32',env:{...process.env,ONNXRUNTIME_NODE_INSTALL:'skip'}});
if(npm.status)throw new Error('Platform dependency staging failed');
// Retain only this platform's native binaries. Models/browser/runtime are separately pinned.
const modules=join(skill,'node_modules');
const files=[];const licenses=[];
async function walk(dir){
 for(const e of await readdir(dir,{withFileTypes:true})){
   const p=join(dir,e.name);if(e.isDirectory())await walk(p);else if(e.isFile()){
   const rel=relative(skill,p).replaceAll('\\','/');
   if(['PACKAGE-MANIFEST.json','THIRD-PARTY-PACKAGES.json'].includes(rel))continue;
   if(rel.startsWith('node_modules/onnxruntime-node/bin/napi-v6/')&&!rel.startsWith('node_modules/onnxruntime-node/bin/napi-v6/'+platform+'/'+arch+'/'))continue;
   if(rel.startsWith('node_modules/@img/')&&/sharp(?:-libvips)?-(?:darwin|linux|linuxmusl|win32)-/.test(rel)&&!rel.includes('-'+platform+'-'+arch+'/'))continue;
   const h=createHash('sha256');await pipeline(createReadStream(p),async function*(src){for await(const b of src){h.update(b);}}); 
   files.push({path:rel,bytes:(await stat(p)).size,sha256:h.digest('hex')});
   if(e.name==='package.json'&&rel.startsWith('node_modules/')){
    try{const info=JSON.parse(await readFile(p,'utf8'));if(info.name&&info.version)licenses.push({name:info.name,version:info.version,license:info.license||'SEE_PACKAGE_NOTICE',path:rel});}catch{}
   }
  }
 }
}
await walk(skill);
const manifest={schemaVersion:1,name:'kordoc-workbench',version:pkg.version,platform,arch,engine:{version:'4.18.13',commit:'969526345dde7d6acd2f2bfd3c8e592069333355'},runtime:JSON.parse(await readFile(join(outRuntime,'runtime-'+platform+'-'+arch+'.json'),'utf8')),networkRequiredAtUse:false,verification:'runtime tests recorded separately; package creation is not environment certification',files,licenses};
await writeFile(join(skill,'PACKAGE-MANIFEST.json'),JSON.stringify(manifest,null,2));await writeFile(join(skill,'THIRD-PARTY-PACKAGES.json'),JSON.stringify(licenses,null,2));
await mkdir('packages',{recursive:true});const out=resolve('packages/kordoc-workbench-0.1.0-'+platform+'-'+arch+'.zip');
const archive=spawnSync('python',['tools/package.py',skill,out],{stdio:'inherit'});
if(archive.status)throw new Error('Sequential ZIP packaging failed');
