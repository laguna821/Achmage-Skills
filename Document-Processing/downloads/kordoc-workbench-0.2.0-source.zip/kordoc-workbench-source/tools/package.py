import hashlib, json, os, sys, zipfile
from pathlib import Path
root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
if not root.is_dir() or root.name != "kordoc-workbench":
    raise SystemExit("Expected explicit staged skill directory")
manifest = json.loads((root / "PACKAGE-MANIFEST.json").read_text(encoding="utf-8"))
entries = manifest["files"] + [{"path": "PACKAGE-MANIFEST.json"}, {"path": "THIRD-PARTY-PACKAGES.json"}]
temporary = out.with_suffix(".zip.tmp")
out.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
    for entry in entries:
        path = (root / entry["path"]).resolve()
        if not path.is_relative_to(root): raise SystemExit("Archive path escapes staging")
        name = "kordoc-workbench/" + entry["path"]
        with path.open("rb") as source:
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            mode = 0o755 if (entry["path"].endswith("/node") or "chrome-headless-shell" in path.name) else 0o644
            info.external_attr = mode << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            with archive.open(info, "w", force_zip64=True) as target:
                while chunk := source.read(1024 * 1024): target.write(chunk)
with zipfile.ZipFile(temporary) as check:
    error = check.testzip()
    if error: raise SystemExit("Archive CRC error: " + error)
os.replace(temporary, out)
h = hashlib.sha256()
with out.open("rb") as stream:
    while chunk := stream.read(1024 * 1024): h.update(chunk)
print(json.dumps({"path": str(out), "bytes": out.stat().st_size, "sha256": h.hexdigest(), "fileCount":len(entries), "crcVerified":True}))

