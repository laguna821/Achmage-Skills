import {mkdtemp,writeFile,readFile,mkdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {resolve,join,dirname} from 'node:path';
import {spawn} from 'node:child_process';
import JSZip from 'jszip';
import sharp from 'sharp';
const temp=await mkdtemp(join(tmpdir(),'kordoc-extensions-'));
const zip=await JSZip.loadAsync(await readFile('packages/kordoc-workbench-0.2.0-core.zip'));
for(const [name,entry]of Object.entries(zip.files)){if(entry.dir)continue;const p=join(temp,name);await mkdir(dirname(p),{recursive:true});await writeFile(p,await entry.async('nodebuffer'));}
const runner=join(temp,'kordoc-workbench/scripts/run.mjs'),results=[];
const env={...process.env,NODE_PATH:'',KORDOC_WORKBENCH_CACHE:resolve('.cache/lean-extension-check')};delete env.KORDOC_OFFLINE;delete env.KORDOC_MODEL_CACHE;delete env.PUPPETEER_EXECUTABLE_PATH;
async function run(req){const input=join(temp,'request-'+results.length+'.json');await writeFile(input,JSON.stringify({schemaVersion:1,outputDir:join(temp,'out-'+results.length),...req}));const result=await new Promise((yes,no)=>{const p=spawn(process.execPath,[runner,input],{cwd:temp,env,windowsHide:true});let out='';p.stdout.on('data',x=>out+=x);p.stderr.on('data',x=>process.stderr.write(x));p.on('error',no);p.on('close',()=>{try{yes(JSON.parse(out));}catch{no(Error(out));}});});results.push({request:req,result});console.log(JSON.stringify({mode:req.mode,format:req.format,status:result.status,failure:result.failure,markdown:result.data?.markdown?.slice(0,200)}));await writeFile('validation/lean-extensions.json',JSON.stringify({temp,node:process.version,results},null,2));return result;}
const generated=await run({mode:'generate',markdown:'# 경량 보고서\n\n한국어 문서 검증\n\n| 항목 | 결과 |\n| --- | --- |\n| 처리 | 완료 |'});
if(!generated.success)throw Error('Core generation failed');const doc=generated.files[0].path;
await run({mode:'render',format:'png',input:doc});
const pdf=await run({mode:'render',format:'pdf',input:doc});
if(pdf.files?.length)await run({mode:'read',input:pdf.files[0].path,options:{ocr:'off'}});
const scan=join(temp,'korean.png');await sharp(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="180"><rect width="100%" height="100%" fill="white"/><text x="30" y="100" font-family="Malgun Gothic" font-size="48">한국어 보고서 작성 검증</text></svg>')).png().toFile(scan);
await run({mode:'ocr',input:scan});
await run({mode:'capabilities'});
if(results.some(x=>x.result.status==='failed'))process.exitCode=1;
