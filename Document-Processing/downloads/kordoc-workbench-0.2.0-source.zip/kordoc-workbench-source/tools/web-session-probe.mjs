import { readFile,writeFile } from 'node:fs/promises';
import JSZip from 'jszip';
const source=await JSZip.loadAsync(await readFile('packages/kordoc-web-probe.zip'));
const zip=new JSZip();
for(const name of ['SKILL.md','scripts/probe.mjs','NODE-LICENSE','KORDOC-LICENSE']){
 let bytes=await source.file('kordoc-web-probe/'+name).async('nodebuffer');
 if(name==='SKILL.md')bytes=Buffer.from(bytes.toString().replace('bundled kordoc HWPX','kordoc HWPX').replace('bundled Node cannot execute','session Node runtime is missing').replace('This is a synthetic runtime probe','This uses an existing session Node runtime and bundles only the official engine code. It tests execution capability without implying that full offline assets fit upload limits. This is a synthetic runtime probe'));
 zip.file('kordoc-web-probe/'+name,bytes);
}
zip.file('kordoc-web-probe/scripts/probe.py',`import json, os, pathlib, shutil, subprocess, sys, tempfile
root = pathlib.Path(__file__).resolve().parent.parent
node = shutil.which("node")
if not node:
    print(json.dumps({"success":False,"code":"SESSION_NODE_MISSING","platform":sys.platform}))
    sys.exit(1)
out = pathlib.Path("/mnt/data/kordoc-probe") if pathlib.Path("/mnt/data").exists() else pathlib.Path(tempfile.mkdtemp(prefix="kordoc-probe-"))
out.mkdir(parents=True, exist_ok=True)
p = subprocess.run([node, str(root/"scripts/probe.mjs"), str(out)], capture_output=True, text=True, env={**os.environ,"KORDOC_OFFLINE":"1"}, timeout=120)
print(p.stdout)
if p.stderr: print(p.stderr,file=sys.stderr)
sys.exit(p.returncode)
`);
const b=await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE',compressionOptions:{level:9}});
await writeFile('packages/kordoc-web-session-probe.zip',b);console.log(JSON.stringify({path:'packages/kordoc-web-session-probe.zip',bytes:b.length}));

