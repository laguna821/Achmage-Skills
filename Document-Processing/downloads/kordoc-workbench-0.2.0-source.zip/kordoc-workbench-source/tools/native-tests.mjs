import { pathToFileURL } from 'node:url';
const { execute }=await import(process.env.KORDOC_TEST_RUNNER?pathToFileURL(process.env.KORDOC_TEST_RUNNER).href:'../skill/kordoc-workbench/scripts/run.mjs');
import { mkdir,writeFile,readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import sharp from 'sharp';
import * as k from 'kordoc';
import JSZip from 'jszip';
const root=resolve('outputs/native-verification-'+Date.now());await mkdir(root,{recursive:true});
let i=0;const results=[];
const run=async(req)=>{const r=await execute({schemaVersion:1,...req,outputDir:resolve(root,'job-'+(++i))});results.push({mode:req.mode,format:req.format,result:r});return r;};
const image=resolve(root,'korean.png');
const svg='<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="350"><rect width="100%" height="100%" fill="white"/><text x="50" y="100" font-family="Malgun Gothic" font-size="52">한국어 문서 처리 검증</text><text x="50" y="210" font-family="Malgun Gothic" font-size="48">보고서 작성 2026년 10월</text></svg>';
await sharp(Buffer.from(svg)).png().toFile(image);
await run({mode:'ocr',input:image,options:{ocr:'force'}});
const formulaImage=resolve(root,'formula.png');
await sharp(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="400"><rect width="100%" height="100%" fill="white"/><text x="100" y="180" font-family="Times New Roman" font-size="90">E = mc²</text></svg>')).png().toFile(formulaImage);
const markdown='# 네이티브 전체 기능 검증\n\n![한국어 스캔](korean.png)\n\n![수식](formula.png)\n\n$$ x^2 + \\frac{1}{2} $$\n\n```chart\ntype: column\ncat: A, B\n값: 3, 5\n```\n\n<table><tr><th colspan="2">병합 머리행</th></tr><tr><td>대상</td><td>결과</td></tr></table>';
const doc=await run({mode:'generate',markdown,images:{'korean.png':image,'formula.png':formulaImage}});
if(doc.status==='failed')throw new Error(JSON.stringify(doc));
const zip=await JSZip.loadAsync(await readFile(doc.files[0].path));const section=await zip.file('Contents/section0.xml').async('string');
results.push({check:'native-equation-and-chart',hasEquation:section.includes('<hp:equation'),hasChart:section.includes('<hp:chart'),embedded:zip.filter(name=>name.startsWith('BinData/')).length});
const pdf=await run({mode:'render',input:doc.files[0].path,format:'pdf'});
if(pdf.status!=='failed'){
 await run({mode:'ocr',input:pdf.files[0].path,options:{ocr:'force',formulaOcr:true}});
}
await writeFile(resolve(root,'results.json'),JSON.stringify(results,null,2));
console.log(JSON.stringify(results.map(x=>({mode:x.mode,format:x.format,status:x.result?.status,failure:x.result?.failure,check:x.check,hasEquation:x.hasEquation,hasChart:x.hasChart,ocr:x.result?.data?.markdown?.slice(0,500)})),null,2));
