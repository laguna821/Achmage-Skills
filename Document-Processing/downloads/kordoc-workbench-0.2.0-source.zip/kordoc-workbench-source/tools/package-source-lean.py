"""Create a reproducible public source archive; never include private templates or sessions."""
from pathlib import Path
import hashlib, json, zipfile
root=Path(__file__).resolve().parents[1]
files=[root/n for n in ('package.json','package-lock.json','LICENSE','LEAN-README.md')]
for name in ('skill','tools','tests'):
    files.extend(p for p in (root/name).rglob('*') if p.is_file() and not {'__pycache__','runtime','node_modules','.cache'}.intersection(p.relative_to(root).parts) and not p.name.endswith('.pyc'))
dest=root/'packages/kordoc-workbench-0.2.0-source.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        info=zipfile.ZipInfo('kordoc-workbench-source/'+p.relative_to(root).as_posix(),date_time=(1980,1,1,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,p.read_bytes())
print(json.dumps({'name':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'privateDataIncluded':False}))
if dest.stat().st_size>10_000_000:
    raise SystemExit('Source archive exceeds release size limit')
