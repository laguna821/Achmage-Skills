import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { build } from 'esbuild';
import { resolve } from 'node:path';
const dest=resolve('skill/kordoc-workbench/scripts/vendor');
await mkdir(dest,{recursive:true});
for(const name of ['documentStyle','hwpxPostProcess','gongmunStyle']){
  let s=await readFile(resolve('../hanmark/src/io/'+name+'.ts'),'utf8');
  s='// Adapted from MIT HanMark 2.7.0, commit 3db078d75851ae8d94dcc96eff45a6fad1102d63\n'+s.replace('import { t } from "../i18n";','const t = (key: string, vars?: Record<string, unknown>) => key + (vars ? " " + JSON.stringify(vars) : "");');
  s=s.replace(/errorHandler: \{\s*warning: \(\) => undefined,\s*error: \(message\) => errors.push\(String\(message\)\),\s*fatalError: \(message\) => errors.push\(String\(message\)\)\s*\}/g, 'onError: (level, message) => { if (level !== "warning") errors.push(String(message)); }');
  if(name==='documentStyle') s+=`
/** Explicit role bindings selected from extraction evidence; formatting is read from XML. */
export async function extractBoundStyles(input: Uint8Array, bindings: Record<string,{charPrId:string;paraPrId:string}>) {
  const zip = await JSZip.loadAsync(input);
  const header = parseXml(await zip.file("Contents/header.xml")!.async("string"), "header.xml");
  const fonts = fontMaps(header);
  const chars = new Map(elements(header,"charPr").map(x=>[x.getAttribute("id"),x]));
  const paras = new Map(elements(header,"paraPr").map(x=>[x.getAttribute("id"),x]));
  return Object.fromEntries(Object.entries(bindings).map(([role,b])=>{
    if(!ROLE_KEYS.includes(role as DocumentStyleRole)||!chars.has(b.charPrId)||!paras.has(b.paraPrId)) throw new Error("INVALID_ROLE_BINDING:"+role);
    return [role,{character:extractedCharacter(chars.get(b.charPrId),fonts),paragraph:extractedParagraph(paras.get(b.paraPrId))}];
  }));
}
`;
  await writeFile(resolve(dest,name+'.ts'),s);
  await build({entryPoints:[resolve(dest,name+'.ts')],outfile:resolve(dest,name+'.mjs'),bundle:false,format:'esm',platform:'node',target:'node20'});
}
await writeFile(resolve(dest,'ORIGIN.json'),JSON.stringify({repository:'https://github.com/laguna821/hanmark',commit:'3db078d75851ae8d94dcc96eff45a6fad1102d63',license:'MIT',changes:['Removed UI translation dependency','Added explicit XML role bindings']},null,2));
await writeFile(resolve(dest,'LICENSE-HANMARK'),await readFile('../hanmark/LICENSE'));
