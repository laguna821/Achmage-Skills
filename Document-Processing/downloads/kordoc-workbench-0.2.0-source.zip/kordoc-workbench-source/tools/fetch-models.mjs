import { build } from 'esbuild';
import { mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const source=process.argv[2];if(!source)throw new Error('Pinned upstream source path required');
await mkdir('.cache',{recursive:true});
process.env.KORDOC_MODEL_CACHE=resolve('skill/kordoc-workbench/runtime/models');
delete process.env.KORDOC_OFFLINE;
for(const [name,entry,method] of [['ocr','src/ocr/models.ts','ensureOcrModels'],['formula','src/pdf/formula/models.ts','ensureFormulaModels']]){
 const out=resolve('.cache/'+name+'-models.mjs');
 await build({entryPoints:[resolve(source,entry)],outfile:out,bundle:true,platform:'node',format:'esm',target:'node20'});
 const m=await import(pathToFileURL(out));
 await m[method]((event)=>{if(event.phase!=='download')process.stderr.write(event.spec.filename+': '+event.phase+'\n');});
 console.log(name+' models verified');
}
