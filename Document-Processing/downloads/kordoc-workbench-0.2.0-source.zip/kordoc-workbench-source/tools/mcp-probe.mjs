import { spawn } from 'node:child_process';
import { join,resolve } from 'node:path';
import { createInterface } from 'node:readline';
const root=resolve(process.argv[2]);
const p=spawn(join(root,'runtime/win32-x64/node.exe'),[join(root,'node_modules/kordoc/dist/cli.js'),'mcp'],{env:{...process.env,KORDOC_OFFLINE:'1',KORDOC_MODEL_CACHE:join(root,'runtime/models'),ORT_DISABLE_TELEMETRY:'1'},stdio:['pipe','pipe','pipe']});
let diagnostics='';p.stderr.on('data',b=>{diagnostics+=b;});
const rl=createInterface({input:p.stdout});
const send=x=>p.stdin.write(JSON.stringify(x)+'\n');
const result=await new Promise((resolve,reject)=>{
 const timer=setTimeout(()=>reject(new Error('MCP timeout: '+diagnostics.slice(-2000))),15000);
 p.on('error',reject);
 rl.on('line',line=>{
  let x;try{x=JSON.parse(line);}catch{return;}
  if(x.error){clearTimeout(timer);reject(new Error(JSON.stringify(x.error)));}
  if(x.id===1){send({jsonrpc:'2.0',method:'notifications/initialized'});send({jsonrpc:'2.0',id:2,method:'tools/list',params:{}});}
  if(x.id===2){clearTimeout(timer);resolve({status:'success',toolCount:x.result.tools.length,tools:x.result.tools.map(t=>t.name)});}
 });
 send({jsonrpc:'2.0',id:1,method:'initialize',params:{protocolVersion:'2025-03-26',capabilities:{},clientInfo:{name:'kordoc-workbench-validation',version:'0.1.0'}}});
}).finally(()=>{rl.close();p.kill();});
console.log(JSON.stringify(result));
