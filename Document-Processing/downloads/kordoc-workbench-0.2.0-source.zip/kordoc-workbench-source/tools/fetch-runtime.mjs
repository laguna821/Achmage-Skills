import { mkdir,writeFile,readFile,cp } from 'node:fs/promises';
import { resolve,join } from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import JSZip from 'jszip';
const platform=process.argv[2]||process.platform,arch=process.argv[3]||process.arch;
const nodeVersion='v22.23.3',browserVersion='154.0.8037.92';
const cache=resolve('.cache/downloads'),root=resolve('skill/kordoc-workbench/runtime');
await mkdir(cache,{recursive:true});await mkdir(root,{recursive:true});
async function download(url,path){
 try{return await readFile(path);}catch{}
 const r=await fetch(url);if(!r.ok)throw new Error(url+': '+r.status);
 const data=Buffer.from(await r.arrayBuffer());await writeFile(path,data);return data;
}
async function unzip(bytes,dest){
 const zip=await JSZip.loadAsync(bytes);await mkdir(dest,{recursive:true});
 for(const [name,file]of Object.entries(zip.files)){
  if(name.split('/').includes('..')||name.startsWith('/'))throw new Error('Unsafe archive path');
  if(file.dir){await mkdir(join(dest,name),{recursive:true});continue;}
  const target=join(dest,name);await mkdir(resolve(target,'..'),{recursive:true});await writeFile(target,await file.async('nodebuffer'));
 }
}
const nodeBase='https://nodejs.org/dist/'+nodeVersion+'/';
const nodeName=platform==='win32'?'node-'+nodeVersion+'-win-'+arch+'.zip':'node-'+nodeVersion+'-'+(platform==='darwin'?'darwin':platform)+'-'+arch+'.tar.xz';
const checks=(await download(nodeBase+'SHASUMS256.txt',join(cache,'node-'+nodeVersion+'-SHASUMS256.txt'))).toString();
const expected=checks.split('\n').find(l=>l.endsWith('  '+nodeName))?.split(' ')[0];
if(!expected)throw new Error('Unsupported Node platform');
const bytes=await download(nodeBase+nodeName,join(cache,nodeName));
const actual=createHash('sha256').update(bytes).digest('hex');
if(expected!==actual)throw new Error('Node SHA mismatch');
const extraction=join(cache,'node-extracted-'+platform+'-'+arch);await mkdir(extraction,{recursive:true});
if(platform==='win32')await unzip(bytes,extraction);
else{const p=spawnSync('tar',['-xf',join(cache,nodeName),'-C',extraction],{encoding:'utf8'});if(p.status)throw new Error(p.stderr);}
const nodeDest=join(root,platform+'-'+arch);await mkdir(nodeDest,{recursive:true});
const prefix=join(extraction,'node-'+nodeVersion+'-'+(platform==='win32'?'win':platform)+'-'+arch);
await cp(platform==='win32'?join(prefix,'node.exe'):join(prefix,'bin'),platform==='win32'?join(nodeDest,'node.exe'):join(nodeDest,'bin'),{recursive:true});
for(const file of ['LICENSE','README.md'])await cp(join(prefix,file),join(nodeDest,file));
const cftPlatform=platform==='win32'?(arch==='x64'?'win64':'win32'):platform==='linux'?(arch==='x64'?'linux64':'linux-arm64'):(arch==='arm64'?'mac-arm64':'mac-x64');
const chromiumUrl='https://storage.googleapis.com/chrome-for-testing-public/'+browserVersion+'/'+cftPlatform+'/chrome-headless-shell-'+cftPlatform+'.zip';
const browserBytes=await download(chromiumUrl,join(cache,'chromium-'+browserVersion+'-'+cftPlatform+'.zip'));
const browserExtraction=join(cache,'chromium-extracted-'+platform+'-'+arch);
await unzip(browserBytes,browserExtraction);
await cp(join(browserExtraction,'chrome-headless-shell-'+cftPlatform),join(root,'chromium-'+platform+'-'+arch),{recursive:true});
await writeFile(join(root,'runtime-'+platform+'-'+arch+'.json'),JSON.stringify({platform,arch,node:{version:nodeVersion,url:nodeBase+nodeName,sha256:actual},chromium:{version:browserVersion,url:chromiumUrl,sha256:createHash('sha256').update(browserBytes).digest('hex'),entry:'chrome-headless-shell'+(platform==='win32'?'.exe':'')}},null,2));
console.log(JSON.stringify({platform,arch,nodeVersion,browserVersion,verified:true}));
