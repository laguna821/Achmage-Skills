import * as k from 'kordoc';
import JSZip from 'jszip';
import { DOMParser } from '@xmldom/xmldom';
import { readFile } from 'node:fs/promises';
import { basename } from 'node:path';
import { ENGINE,sha256,stable,fail,toArray,artifact,warn,takeWarnings } from './common.mjs';
import { extractDocumentStyleProfile,normalizeDocumentStyleProfile,extractBoundStyles } from './vendor/documentStyle.mjs';
const roles=['body','h1','h2','h3','h4','h5','h6','quote','code','list'];
export function packContent(pack){
  const {contentHash,validation,createdAt,...content}=pack;return content;
}
export function hashPack(pack){return sha256(stable(packContent(pack)));}
export function validatePack(p){
  if(!p||p.schemaVersion!==1||p.kind!=='kordoc-template-pack'||typeof p.id!=='string'||typeof p.name!=='string'||typeof p.markdownSkeleton!=='string'||!Array.isArray(p.fields)||!p.source||!Array.isArray(p.assets)||!Array.isArray(p.tableRules)||!Array.isArray(p.evidence)||!Array.isArray(p.limitations)) fail('INVALID_TEMPLATE_PACK','Incomplete TemplatePack v1');
  if(p.contentHash!==hashPack(p)) fail('HASH_MISMATCH','TemplatePack content hash mismatch');
  if(!/^[a-zA-Z0-9_.-]{1,100}$/.test(p.id)) fail('INVALID_TEMPLATE_PACK','Invalid template ID');
  if(p.documentStyle) normalizeDocumentStyleProfile(p.documentStyle);
  if(p.gongmun?.preset&&!['official','report','plan','notice','minutes','gaejosik','ministry','bangchim','press'].includes(p.gongmun.preset)) fail('INVALID_TEMPLATE_PACK','Unknown preset');
  for(const a of p.assets){if(!a.name||a.name!==basename(a.name)||typeof a.base64!=='string'||sha256(Buffer.from(a.base64,'base64'))!==a.sha256) fail('INVALID_ASSET','Template asset hash or name invalid');}
  return p;
}
export async function loadPack(path){return validatePack(JSON.parse(await readFile(path,'utf8')));}
export async function styleEvidence(bytes){
  const zip=await JSZip.loadAsync(bytes);const result=[];
  for(const [name,entry] of Object.entries(zip.files)){
    if(!/^Contents\/section\d+\.xml$/.test(name))continue;
    const xml=await entry.async('string');const doc=new DOMParser().parseFromString(xml,'text/xml');
    for(const p of Array.from(doc.getElementsByTagName('hp:p'))){
      const runs=Array.from(p.childNodes).filter(n=>n.nodeType===1&&n.localName==='run');
      const text=runs.map(r=>Array.from(r.getElementsByTagName('hp:t')).map(t=>t.textContent||'').join('')).join('');
      if(!text.trim())continue;
      result.push({section:name,paragraphId:p.getAttribute('id'),text:text.slice(0,160),charPrIds:[...new Set(runs.map(r=>r.getAttribute('charPrIDRef')))],paraPrId:p.getAttribute('paraPrIDRef'),styleId:p.getAttribute('styleIDRef'),authority:'xml-direct'});
    }
  }return result;
}
async function correctExplicitNoUnderline(bytes,profile){
  const zip=await JSZip.loadAsync(bytes),header=zip.file('Contents/header.xml');if(!header)return [];
  const doc=new DOMParser().parseFromString(await header.async('string'),'text/xml');const corrected=[];
  for(const cp of Array.from(doc.getElementsByTagName('hh:charPr'))){
    const underline=Array.from(cp.childNodes).find(n=>n.nodeType===1&&n.localName==='underline');
    if(underline?.getAttribute('type')!=='NONE')continue;
    const id=cp.getAttribute('id');for(const table of profile.tables||[]){const def=table.used_char_prs?.[id];if(def?.underline){def.underline=false;corrected.push({table:table.table_index,charPrId:id});}}
  }return corrected;
}
export async function analyzeTemplate(req,ctx){
  const bytes=await ctx.read(req.input);const parsed=await k.parse(bytes,{layoutTables:'keep',keepTrailingEmptyCols:true,includeFieldPlaceholders:true,...req.options});
  if(!parsed.success)fail(parsed.code||'PARSE_ERROR',parsed.error);
  takeWarnings(ctx,parsed.warnings);
  const pack={kind:'kordoc-template-pack',schemaVersion:1,id:req.templateId||'template-'+sha256(bytes).slice(0,16),version:'1.0.0',name:req.name||basename(req.input),source:{name:basename(req.input),sha256:sha256(bytes),format:parsed.fileType},engine:ENGINE,markdownSkeleton:parsed.markdown,fields:k.extractFormSchema(parsed.blocks).fields||[],tableRules:req.tableRules||[],assets:[],evidence:[],limitations:[],documentStyle:undefined,tableProfile:undefined,gongmun:req.gongmun};
  if(parsed.fileType==='hwpx'){
    pack.documentStyle=await extractDocumentStyleProfile(toArray(bytes),pack.name);
    pack.tableProfile=await k.hwpxToProfile(bytes);pack.evidence=await styleEvidence(bytes);
    const corrected=await correctExplicitNoUnderline(bytes,pack.tableProfile);
    if(corrected.length)pack.evidence.push({authority:'xml-direct',normalization:'Explicit underline type NONE corrected after kordoc 4.18.13 extraction',entries:corrected});
    if(req.roleBindings){const bindings=await extractBoundStyles(bytes,req.roleBindings);Object.assign(pack.documentStyle.roles,bindings);pack.evidence.push({authority:'xml-direct',roleBindings:req.roleBindings,meaning:'user-or-agent-role-mapping'});}
    pack.limitations.push('Direct formatting differs per paragraph; bind roles explicitly from evidence to reproduce unnamed styles.','Nested tables, shapes and cell paragraph alignment/margins are outside FormatProfile.');
  }else{
    if(req.inferredStyle){pack.documentStyle=normalizeDocumentStyleProfile(req.inferredStyle);pack.evidence.push({authority:'ai-inferred',paths:['documentStyle'],reason:req.inferenceReason||'Reference appearance interpreted by agent'});}
    pack.limitations.push('Whole-document style not directly extracted from '+parsed.fileType+'. Inferred values need visual verification.');
    warn(ctx,'STYLE_INFERENCE_REQUIRED',pack.limitations[0],true);
  }
  for(const image of parsed.images||[]){
    // Preserve actual embedded assets; never embed user-supplied arbitrary file references.
    const data=typeof image.data==='string'?Buffer.from(image.data,'base64'):Buffer.from(image.data||[]);
    if(!data.length)continue;
    pack.assets.push({name:basename(image.filename||image.name||('image-'+pack.assets.length+'.png')),sha256:sha256(data),base64:data.toString('base64'),mimeType:image.mimeType});
  }
  pack.validation={structural:parsed.fileType==='hwpx'?await k.validateHwpx(bytes):{status:'not-applicable'},visual:'pending',hanmark:{engineVersion:'4.15.7',status:'pending'}};
  pack.contentHash=hashPack(pack);validatePack(pack);
  await artifact(ctx,'template.kordoc-template.json',JSON.stringify(pack,null,2),'application/json');
  await artifact(ctx,'skeleton.md',pack.markdownSkeleton,'text/markdown');
  ctx.data=pack;
}
export async function adaptTables(pack,markdown,options,ctx){
  if(!pack.tableRules.length)return pack.tableProfile;
  const current=await k.hwpxToProfile(await k.markdownToHwpx(markdown,options));
  const profile=structuredClone(pack.tableProfile||current);
  for(const rule of pack.tableRules){
    const old=profile.tables.find(t=>t.table_index===rule.tableIndex)||profile.tables[rule.tableIndex];
    const target=current.tables.find(t=>t.table_index===rule.tableIndex)||current.tables[rule.tableIndex];
    if(!old||!target||old.cols!==target.cols)fail('TABLE_RULE_MISMATCH','Variable table column count/index mismatch');
    const head=rule.headerRows??1,dataRow=rule.dataRow??head;
    const dataCells=old.cells.filter(c=>c.row===dataRow);
    if(dataCells.length!==old.cols||dataCells.some(c=>(c.rowSpan??1)!==1||(c.colSpan??1)!==1))fail('UNSUPPORTED_TABLE_RULE','Repeating data row must be unmerged');
    const cells=target.cells.map(c=>{
      const source=old.cells.find(s=>s.row===(c.row<head?c.row:dataRow)&&s.col===c.col);
      if(!source)fail('TABLE_RULE_MISMATCH','Missing source cell');
      return {...c,borderFillIDRef:source.borderFillIDRef,charPrIDRef:source.charPrIDRef,height_hwpunit:source.height_hwpunit,width_hwpunit:source.width_hwpunit};
    });
    Object.assign(old,{rows:target.rows,cells,anchor_text:target.anchor_text,anchor_row:target.anchor_row});
    warn(ctx,'VARIABLE_TABLE_EXPANDED','Table '+rule.tableIndex+' expanded to '+target.rows+' rows');
  }
  return profile;
}
export function gongmunStyleFromDocument(profile){
  const b=profile?.roles?.body,h=profile?.roles?.h1,m=profile?.page?.margins;
  return {bodyPt:b?.character?.fontSizePt,lineSpacing:b?.paragraph?.lineSpacingPercent,fonts:{body:b?.character?.fontFamily,heading:h?.character?.fontFamily},...(m?{margins:Object.fromEntries(['top','bottom','left','right'].map(key=>[key,Math.round(m[key]*25.4/7200*100)/100]))}:{})};
}
