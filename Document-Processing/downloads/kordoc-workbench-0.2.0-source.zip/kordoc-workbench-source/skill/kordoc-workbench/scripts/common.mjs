import { createHash } from 'node:crypto';
import { mkdir, writeFile, readFile, realpath } from 'node:fs/promises';
import { resolve, dirname, relative, isAbsolute } from 'node:path';
export const ENGINE={name:'kordoc',version:'4.18.13',commit:'969526345dde7d6acd2f2bfd3c8e592069333355'};
export const sha256=v=>createHash('sha256').update(v).digest('hex');
export const stable=v=>JSON.stringify(v,(_k,x)=>x && typeof x==='object'&&!Array.isArray(x)&&!(x instanceof Uint8Array)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
export function fail(code,message,details){throw Object.assign(new Error(message),{code,details});}
export function toArray(b){return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);}
export async function inputBytes(path){
  if(typeof path!=='string') fail('INVALID_REQUEST','input must be a path');
  const p=resolve(path); const b=await readFile(p);
  if(process.env.KORDOC_ROOT){const root=await realpath(process.env.KORDOC_ROOT), actual=await realpath(p), rel=relative(root,actual); if(rel.startsWith('..')||isAbsolute(rel)) fail('OUTSIDE_ROOT','Input outside KORDOC_ROOT');}
  return b;
}
export async function artifact(ctx,name,data,mimeType){
  if(typeof name!=='string'||name!==name.split(/[\\/]/).pop()||!name||name==='..') fail('INVALID_OUTPUT','Artifact name must be a basename');
  const target=resolve(ctx.outputDir,name);
  await mkdir(dirname(target),{recursive:true});
  // Exclusive create: never overwrite input or an existing output, even across concurrent jobs.
  await writeFile(target,data,{flag:'wx'});
  const b=typeof data==='string'?Buffer.from(data):Buffer.from(data);
  const file={path:target,sha256:sha256(b),bytes:b.length,mimeType};
  ctx.files.push(file);return file;
}
export function warn(ctx,code,message,partial=false){ctx.warnings.push({code,message});if(partial)ctx.partial=true;}
export const significantWarning=w=>!['OCR_APPLIED','OCR_FALLBACK','PAGE_BOUNDARY_APPROXIMATE'].includes(w.code);
export function takeWarnings(ctx,list=[]){for(const x of list){const w=typeof x==='string'?{code:'ENGINE_WARNING',message:x}:x;ctx.warnings.push(w);if(significantWarning(w))ctx.partial=true;}}
export function cleanJson(v){if(v===undefined)return undefined;return JSON.parse(JSON.stringify(v,(_k,x)=>x instanceof Uint8Array?{encoding:'base64',data:Buffer.from(x).toString('base64')}:x instanceof ArrayBuffer?{encoding:'base64',data:Buffer.from(x).toString('base64')}:x instanceof Map?Object.fromEntries(x):x));}
