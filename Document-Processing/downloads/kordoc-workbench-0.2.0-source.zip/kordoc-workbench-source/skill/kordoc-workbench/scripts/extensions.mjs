import { readFile, writeFile, mkdir, cp, access, open, unlink } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { homedir } from 'node:os';
import { resolve, dirname, join, extname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import JSZip from 'jszip';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
export const cache=resolve(process.env.KORDOC_WORKBENCH_CACHE||join(homedir(),'.kordoc-workbench/cache/0.2.0'),process.platform+'-'+process.arch);
const groupFor={'sharp':'raster','pdfjs-dist':'pdf','@hyzyla/pdfium':'pdf','onnxruntime-node':'ocr','onnxruntime-web':'formula','@huggingface/transformers':'formula','puppeteer-core':'print'};
const error=(code,message)=>Object.assign(new Error(message),{code});
export function extensionUrl(name){
 const group=Object.keys(groupFor).find(p=>name===p||name.startsWith(p+'/'));
 if(!group)throw error('MISSING_DEPENDENCY','Unknown optional module: '+name);
 const req=createRequire(join(cache,groupFor[group],'package.json'));
 return pathToFileURL(req.resolve(name)).href;
}
export function extensionPath(name){return fileURLToPath(extensionUrl(name));}
async function download(url,sha,target){
 try{const old=await readFile(target);if(createHash('sha256').update(old).digest('hex')===sha)return old;}catch{}
 if(process.env.KORDOC_OFFLINE==='1')throw error('DEPENDENCY_UNAVAILABLE_OFFLINE','Missing verified asset: '+target);
 const response=await fetch(url);if(!response.ok)throw error('ASSET_DOWNLOAD_FAILED',url+': '+response.status);
 const bytes=Buffer.from(await response.arrayBuffer());if(createHash('sha256').update(bytes).digest('hex')!==sha)throw error('ASSET_HASH_MISMATCH',url);
 await mkdir(dirname(target),{recursive:true});await writeFile(target,bytes);return bytes;
}
export async function command(exe,args,opts={}){
 return await new Promise((yes,no)=>{const p=spawn(exe,args,{...opts,stdio:['ignore','pipe','pipe'],windowsHide:true});let out='',err='';p.stdout.on('data',x=>out+=x);p.stderr.on('data',x=>err+=x);p.on('error',no);p.on('close',code=>code===0?yes(out):no(error('DEPENDENCY_SETUP_FAILED',err.slice(-4000)||out.slice(-4000)||'Command failed: '+exe)));});
}
export async function capabilities(){
 const extensions={};for(const group of new Set(Object.values(groupFor)))extensions[group]={ready:existsSync(join(cache,group,'.ready')),status:existsSync(join(cache,group,'.ready'))?'prepared':'not-prepared'};
 return {distribution:'0.2.0',node:process.version,platform:process.platform,arch:process.arch,core:'bundled',cache,extensions,offline:process.env.KORDOC_OFFLINE==='1',web:process.env.KORDOC_WEB==='1',verification:'Preparation status is not end-to-end certification'};
}
export function requiredGroups(req){
 const groups=new Set(),ext=extname(req.input||'').toLowerCase();
 if(ext==='.pdf'||extname(req.other||'').toLowerCase()==='.pdf')groups.add('pdf');
 if(req.mode==='ocr'||req.options?.ocr==='force'||['.png','.jpg','.jpeg','.tif','.tiff','.webp'].includes(ext)){groups.add('ocr');groups.add('raster');}
 if(req.options?.formulaOcr){groups.add('formula');groups.add('ocr');groups.add('raster');}
 if(['crop','tables'].includes(req.mode)||(req.mode==='render'&&['png','jpeg','jpg'].includes(req.format||req.options?.format)))groups.add('raster');
 if(req.mode==='render'&&(req.format||req.options?.format)==='pdf')groups.add('print');
 return [...groups];
}
async function prepareGroup(group,offline){
 const source=join(root,'extensions',group),dest=join(cache,group);
 const lock=await readFile(join(source,'package-lock.json'));
 const hash=createHash('sha256').update(lock).digest('hex');
 try{if((await readFile(join(dest,'.ready'),'utf8'))===hash)return;}catch{}
 if(offline)throw error('DEPENDENCY_UNAVAILABLE_OFFLINE','Prepare extension online first: '+group);
 await mkdir(dest,{recursive:true});
 let lease;try{lease=await open(join(dest,'.installing'),'wx');}catch{throw error('SETUP_IN_PROGRESS','Another setup is running or was interrupted: '+dest);}
 try{
  await cp(join(source,'package.json'),join(dest,'package.json'));await writeFile(join(dest,'package-lock.json'),lock);
  const npm=process.platform==='win32'?'npm.cmd':'npm';
  // npm.cmd requires cmd on Windows; all arguments here are fixed and contain no user input.
  await command(process.platform==='win32'?'cmd.exe':npm,process.platform==='win32'?['/d','/c','npm.cmd ci --ignore-scripts --no-audit --no-fund']:['ci','--ignore-scripts','--no-audit','--no-fund'],{cwd:dest,env:{...process.env,ONNXRUNTIME_NODE_INSTALL:'skip'}});
  await writeFile(join(dest,'.ready'),hash);
 }finally{await lease.close();await unlink(join(dest,'.installing'));}
}
async function browser(){
 const candidates=[process.env.PUPPETEER_EXECUTABLE_PATH,...(process.platform==='win32'?[join(process.env.PROGRAMFILES||'C:/Program Files','Google/Chrome/Application/chrome.exe'),join(process.env['PROGRAMFILES(X86)']||'C:/Program Files (x86)','Microsoft/Edge/Application/msedge.exe'),join(process.env.LOCALAPPDATA||homedir(),'Google/Chrome/Application/chrome.exe')]:process.platform==='darwin'?['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']:['/usr/bin/google-chrome','/usr/bin/chromium','/usr/bin/chromium-browser'])].filter(Boolean);
 const {default:p}=await import(extensionUrl('puppeteer-core'));
 for(const candidate of candidates){if(!existsSync(candidate))continue;try{const b=await p.launch({executablePath:candidate,headless:true,timeout:15000,args:['--no-sandbox']});await b.close();return candidate;}catch{}}
 const manifest=JSON.parse(await readFile(join(root,'ASSETS.json'),'utf8'));
 const spec=manifest.browsers[process.platform+'-'+process.arch];
 if(!spec)throw error('BROWSER_UNAVAILABLE','No compatible installed browser and no verified browser package for this platform');
 const dest=join(cache,'browser',spec.sha256.slice(0,16)),exe=join(dest,spec.entry);
 if(!existsSync(join(dest,'.ready'))){
  const bytes=await download(spec.url,spec.sha256,join(cache,'downloads',spec.sha256+'.zip'));
  const archive=await JSZip.loadAsync(bytes);
  for(const [name,entry]of Object.entries(archive.files)){
   if(name.includes('\\')||name.startsWith('/')||name.split('/').includes('..')||(entry.unsafeOriginalName&&entry.unsafeOriginalName!==name))throw error('INVALID_ARCHIVE','Unsafe browser archive');
   const file=resolve(dest,name);
   if(!file.startsWith(resolve(dest)+(process.platform==='win32'?'\\':'/')))throw error('INVALID_ARCHIVE','Browser entry escapes destination');
   if(entry.dir){await mkdir(file,{recursive:true});continue;}
   await mkdir(dirname(file),{recursive:true});await writeFile(file,await entry.async('nodebuffer'),{mode:0o755});
  }
  const b=await p.launch({executablePath:exe,headless:true,timeout:15000,args:['--no-sandbox']});await b.close();await writeFile(join(dest,'.ready'),spec.sha256);
 }
 return exe;
}
export async function prepare(req){
 const offline=process.env.KORDOC_OFFLINE==='1',groups=requiredGroups(req);
 for(const group of groups)await prepareGroup(group,offline);
 process.env.KORDOC_MODEL_CACHE ||= join(cache,'models');
 if(groups.includes('ocr')){
  const models=await import('./model-prepare.mjs');
  await models.prepareModels(groups.includes('formula'));
 }
 if(groups.includes('print'))process.env.PUPPETEER_EXECUTABLE_PATH=await browser();
 if((groups.includes('print')||groups.includes('raster'))&&process.platform==='linux'){
  let korean='';try{korean=await command('fc-list',[':lang=ko']);}catch{}
  if(!korean.trim()){
   const spec=JSON.parse(await readFile(join(root,'ASSETS.json'),'utf8')).font;
   const fontDir=join(cache,'fonts');await download(spec.url,spec.sha256,join(fontDir,'NotoSansKR-VF.ttf'));
   await writeFile(join(fontDir,'fonts.conf'),'<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd"><fontconfig><include ignore_missing="yes">/etc/fonts/fonts.conf</include><dir prefix="relative">.</dir></fontconfig>');
   process.env.FONTCONFIG_FILE=join(fontDir,'fonts.conf');
  }
 }
 const versions={};for(const group of groups)versions[group]=JSON.parse(await readFile(join(root,'extensions',group,'package.json'),'utf8')).dependencies;
 return {node:process.version,extensions:versions,browser:groups.includes('print')?process.env.PUPPETEER_EXECUTABLE_PATH:undefined};
}
