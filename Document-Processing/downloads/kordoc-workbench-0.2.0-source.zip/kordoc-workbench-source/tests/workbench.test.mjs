import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp,readFile,writeFile,mkdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join,resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import * as k from 'kordoc';
import JSZip from 'jszip';
import sharp from 'sharp';
import {pathToFileURL} from 'node:url';
const {execute,runRequest}=await import(process.env.KORDOC_TEST_RUNNER?pathToFileURL(process.env.KORDOC_TEST_RUNNER).href:'../skill/kordoc-workbench/scripts/run.mjs');
import { sha256 } from '../skill/kordoc-workbench/scripts/common.mjs';
import { hashPack } from '../skill/kordoc-workbench/scripts/templates.mjs';
const root=await mkdtemp(join(tmpdir(),'kordoc-workbench-'));
let counter=0;
const run=r=>execute({schemaVersion:1,outputDir:join(root,'job-'+(++counter)),...r});
const md='# 연구 보고서\n\n성명: 홍길동\n\n연락처: 010-1234-5678\n\n| 항목 | 값 |\n| --- | --- |\n| 성명 | 이전 |\n| 제목 | 이전 제목 |\n\n담당자 (인)\n\n수식 $x^2+1$\n\n<table><tr><th colspan="2">병합</th></tr><tr><td>A</td><td>B</td></tr></table>';
const generated=await run({mode:'generate',markdown:md});
assert.equal(generated.status,'success',JSON.stringify(generated));
const hwpx=generated.files[0].path;
test('parse IR/metadata/pages/RAG and form schema',async()=>{
 const r=await run({mode:'read',input:hwpx,chunks:true,options:{layoutTables:'keep'}});
 assert.equal(r.status,'success');assert.match(r.data.markdown,/연구 보고서/);assert.ok(r.data.blocks.length);assert.ok(r.data.chunks.length);
 const f=await run({mode:'form-analyze',input:hwpx});assert.equal(f.status,'success');assert.ok(f.data.schema);
});
test('nine official presets with frozen date produce valid documents',async()=>{
 for(const preset of ['official','report','plan','notice','minutes','gaejosik','ministry','bangchim','press']){
  const r=await run({mode:'generate',markdown:'# 기관 보고\n\n## 목적\n\n- 자료 정리',frozenDate:'2026. 10. 5.',options:{gongmun:{preset}}});
  assert.notEqual(r.status,'failed',preset+JSON.stringify(r));assert.equal(r.data.validation.ok,true);
 }
 const noDate=await run({mode:'generate',markdown:'# 보고',options:{gongmun:{preset:'gaejosik'}}});assert.equal(noDate.failure.code,'FROZEN_DATE_REQUIRED');
});
test('byte-identical output across separate processes and timezone',async()=>{
 const runner=process.env.KORDOC_TEST_RUNNER||resolve('skill/kordoc-workbench/scripts/run.mjs');const hashes=[];
 for(const tz of ['UTC','Asia/Seoul']){
  const req=join(root,'det-'+tz.replace('/','-')+'.json');await writeFile(req,JSON.stringify({schemaVersion:1,mode:'generate',markdown:md,outputDir:join(root,'det-'+hashes.length)}));
  const p=spawnSync(process.execPath,[runner,req],{encoding:'utf8',env:{...process.env,TZ:tz}});
  assert.equal(p.status,0,p.stdout+p.stderr);hashes.push(JSON.parse(p.stdout).files[0].sha256);
 }assert.equal(hashes[0],hashes[1]);
});
test('fill preserves source parts and reports unmatched fields',async()=>{
 const ambiguous=await run({mode:'fill',input:hwpx,values:{성명:'김교수'},requireUnique:true});
 assert.equal(ambiguous.status,'partial');assert.ok(ambiguous.skipped.fields.includes('성명'));
 const r=await run({mode:'fill',input:hwpx,values:{성명:['김교수','이교수'],없는필드:'값'},requireUnique:true});
 assert.equal(r.status,'partial');assert.ok(r.skipped.fields.includes('없는필드'));assert.equal(r.files.length,1);
 const before=await JSZip.loadAsync(await readFile(hwpx)),after=await JSZip.loadAsync(await readFile(r.files[0].path));
 assert.deepEqual(await before.file('Contents/header.xml').async('nodebuffer'),await after.file('Contents/header.xml').async('nodebuffer'));
 const p=await k.parse(await readFile(r.files[0].path),{layoutTables:'keep'});assert.match(p.markdown,/김교수/);
});
test('builtin draft, repeated values and multiline values',async()=>{
 const built=await run({mode:'fill',builtin:'gian-simple',values:{제목:'다음 사업\n두 번째 줄'},format:'hwpx-preserve'});assert.notEqual(built.status,'failed',JSON.stringify(built));
 const r=await run({mode:'fill',input:hwpx,values:{성명:['첫 사람','둘째 사람']},format:'markdown'});assert.notEqual(r.status,'failed');
});
test('patch and compare preserve originals and show skipped additions',async()=>{
 const parsed=await k.parse(await readFile(hwpx),{layoutTables:'keep'});
 const r=await run({mode:'patch',input:hwpx,markdown:parsed.markdown.replace('연구 보고서','수정 보고서')+'\n\n새 문단'});
 assert.equal(r.status,'partial');assert.ok(r.skipped.edits.length);
 const d=await run({mode:'compare',input:hwpx,other:r.files[0].path});assert.equal(d.status,'success');assert.ok(d.files.some(f=>f.path.endsWith('.md')));
 assert.equal(sha256(await readFile(hwpx)),generated.files[0].sha256);
});
test('SVG HTML PNG JPEG rendering, region and table extraction',async()=>{
 for(const format of ['svg','html','png','jpeg']){
  const r=await run({mode:'render',input:hwpx,format,options:{maxWidthPx:800}});
  assert.notEqual(r.status,'failed',format+JSON.stringify(r));assert.ok(r.files[0].bytes>0);
 }
 const c=await run({mode:'crop',input:hwpx,options:{types:['table'],maxWidthPx:800}});assert.notEqual(c.status,'failed',JSON.stringify(c));assert.ok(c.files.length);
 const t=await run({mode:'tables',input:hwpx});assert.notEqual(t.status,'failed',JSON.stringify(t));assert.ok(t.data.length>=1);
});
test('text redaction detects phone and verifies residuals; seal anchors',async()=>{
 const r=await run({mode:'redact',input:hwpx,options:{rules:['phone']}});
 assert.notEqual(r.status,'failed',JSON.stringify(r));assert.ok(r.data.hits.length);assert.equal(r.data.residualTextHits,0);
 const image=join(root,'seal.png');await sharp({create:{width:50,height:50,channels:4,background:{r:255,g:0,b:0,alpha:.3}}}).png().toFile(image);
 const s=await run({mode:'seal',input:hwpx,operations:[{anchor:'(인)',image,sizeMm:10}]});assert.notEqual(s.status,'failed',JSON.stringify(s));assert.equal(s.data.placed.length,1);
 const bad=await run({mode:'seal',input:hwpx,operations:[{anchor:'미존재',image}]});assert.equal(bad.status,'failed');
});
test('TemplatePack extraction, hash verification and variable table rows',async()=>{
 const a=await run({mode:'template-analyze',input:hwpx,name:'합성 보고 양식'});assert.equal(a.status,'success',JSON.stringify(a));assert.ok(a.data.evidence.length);
 const packPath=a.files[0].path,p=JSON.parse(await readFile(packPath,'utf8'));
 assert.equal(p.contentHash,hashPack(p));assert.equal(p.documentStyle.schemaVersion,3);
 // First table is rectangular. Profile tracks header/data style while target row count changes.
 p.tableRules=[{tableIndex:0,headerRows:1,dataRow:1}];p.contentHash=hashPack(p);const variable=join(root,'variable.json');await writeFile(variable,JSON.stringify(p));
 const r=await run({mode:'template-apply',template:variable,markdown:'# 새 보고\n\n| 항목 | 값 |\n| --- | --- |\n| A | 1 |\n| B | 2 |\n| C | 3 |'});
 assert.notEqual(r.status,'failed',JSON.stringify(r));
 const prof=await k.hwpxToProfile(await readFile(r.files[0].path));assert.equal(prof.tables[0].rows,4);
 p.name='변조';await writeFile(variable,JSON.stringify(p));
 const bad=await run({mode:'template-apply',template:variable,markdown:'# 새 보고'});assert.equal(bad.failure.code,'HASH_MISMATCH');
});
test('unmatched table profile is partial, and NONE underline is normalized from original XML',async()=>{
 const p=await run({mode:'template-analyze',input:resolve('node_modules/kordoc/templates/간이기안문_서식.hwpx')});assert.equal(p.status,'success');
 assert(p.data.evidence.some(e=>e.normalization?.includes('underline type NONE')));
 const generated=await run({mode:'template-apply',template:p.files[0].path,markdown:'# 새 보고\n\n| 성과 | 건수 |\n| --- | --- |\n| 교육 | 3 |'});
 assert.equal(generated.status,'partial',JSON.stringify(generated));assert(generated.warnings.some(w=>w.code==='TABLE_PROFILE_UNAPPLIED'));
});
test('failures: damaged/unknown files, conflict, missing assets, invalid schema, finite batch',async()=>{
 const bad=join(root,'bad.hwpx');await writeFile(bad,'damaged');
 const r=await run({mode:'read',input:bad});assert.equal(r.status,'failed');assert.ok(r.failure.code);
 const dir=join(root,'conflict');const first=await run({mode:'generate',markdown:'# 첫 번째',outputDir:dir});const second=await run({mode:'generate',markdown:'# 두 번째',outputDir:dir});assert.equal(second.failure.code,'OUTPUT_CONFLICT');assert.equal(sha256(await readFile(first.files[0].path)),first.files[0].sha256);
 const missing=await run({mode:'generate',markdown:'![image](missing.png)'});assert.equal(missing.failure.code,'MISSING_ASSET');
 const b=await runRequest({schemaVersion:1,mode:'batch',outputDir:join(root,'batch'),jobs:[{mode:'validate',input:hwpx},{mode:'read',input:bad}]});assert.equal(b.status,'partial');assert.equal(b.success,false);
 const invalid=await execute({mode:'generate'});assert.equal(invalid.failure.code,'INVALID_REQUEST');
});
test('lint returns structural findings and native probe works offline',async()=>{
 const l=await run({mode:'lint',markdown:'2026-10-05 13:00 및 1000000원'});assert.equal(l.status,'success');assert.ok(Array.isArray(l.data.gongmun));
 const r=await run({mode:'capabilities'});assert.equal(r.status,'success',JSON.stringify(r));assert.equal(r.data.core,'bundled');
});
