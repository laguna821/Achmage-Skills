import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import CFB from 'cfb';
import JSZip from 'jszip';
import * as k from 'kordoc';
import {pathToFileURL} from 'node:url';
const {execute}=await import(process.env.KORDOC_TEST_RUNNER?pathToFileURL(process.env.KORDOC_TEST_RUNNER).href:'../skill/kordoc-workbench/scripts/run.mjs');
const root=await mkdtemp(join(tmpdir(),'kordoc-formats-'));
let counter=0;const run=r=>execute({schemaVersion:1,...r,outputDir:join(root,'job-'+(++counter))});
const upstream=process.env.KORDOC_TEST_SOURCE||resolve('.');
const rec=(tag,level,data)=>{const h=Buffer.alloc(4);h.writeUInt32LE(tag|(level<<10)|(data.length<<20));return Buffer.concat([h,data]);};
function paragraph(text){
 const h=Buffer.alloc(24);h.writeUInt32LE(text.length+1);h.writeUInt16LE(1,12);h.writeUInt16LE(1,16);
 return Buffer.concat([rec(0x42,0,h),rec(0x43,1,Buffer.from(text+'\r','utf16le')),rec(0x44,1,Buffer.alloc(8)),rec(0x45,1,Buffer.alloc(36))]);
}
function hwp5(text,flags=0){
 const fh=Buffer.alloc(256);fh.write('HWP Document File');fh[35]=5;fh.writeUInt32LE(flags,36);
 const cfb=CFB.utils.cfb_new();
 CFB.utils.cfb_add(cfb,'/FileHeader',fh);CFB.utils.cfb_add(cfb,'/DocInfo',Buffer.alloc(0));CFB.utils.cfb_add(cfb,'/BodyText/Section0',paragraph(text));
 return CFB.write(cfb,{type:'buffer'});
}
async function zipFile(name,files){
 const zip=new JSZip();for(const [key,value]of Object.entries(files))zip.file(key,value);
 const path=join(root,name);await writeFile(path,await zip.generateAsync({type:'nodebuffer'}));return path;
}
test('HWP3 synthetic parse and encrypted HWP3 with correct/missing/wrong password',async()=>{
 const sig=Buffer.alloc(30);sig.write('HWP Document File V3.00');const text='HWP3 TEST';const ph=Buffer.alloc(43);ph[0]=1;ph.writeUInt16LE(text.length,1);
 const chars=Buffer.alloc(text.length*2);[...text].forEach((c,i)=>chars.writeUInt16LE(c.charCodeAt(0),i*2));
 const file=join(root,'hwp3.hwp');await writeFile(file,Buffer.concat([sig,Buffer.alloc(128),Buffer.alloc(1008),Buffer.alloc(16),ph,chars,Buffer.alloc(43)]));
 const r=await run({mode:'read',input:file});assert.notEqual(r.status,'failed',JSON.stringify(r));assert.match(r.data.markdown,/HWP3 TEST/);
 const encrypted=join(upstream,'tests/fixtures/password/HWP3-password-123456.hwp');
 const ok=await run({mode:'read',input:encrypted,options:{password:'123456'}});assert.notEqual(ok.status,'failed',JSON.stringify(ok));
 for(const password of [undefined,'wrong']){const bad=await run({mode:'read',input:encrypted,options:{password}});assert.equal(bad.status,'failed');assert.ok(['ENCRYPTED','PARSE_ERROR'].includes(bad.failure.code));}
});
test('HWP5 parse, preserve patch, cross-format compare and encryption failure',async()=>{
 const original=hwp5('한국어 HWP 문단');const file=join(root,'synthetic.hwp');await writeFile(file,original);
 const parsed=await run({mode:'read',input:file});assert.equal(parsed.status,'success',JSON.stringify(parsed));assert.match(parsed.data.markdown,/한국어 HWP 문단/);
 const patched=await run({mode:'patch',input:file,markdown:parsed.data.markdown.replace('HWP 문단','수정 문단')});assert.equal(patched.status,'success',JSON.stringify(patched));assert.ok(patched.files[0].path.endsWith('.hwp'));
 assert.equal(Buffer.compare(await readFile(file),original),0);
 const doc=await run({mode:'generate',markdown:parsed.data.markdown});
 const compared=await run({mode:'compare',input:file,other:doc.files[0].path});assert.equal(compared.status,'success');
 const encrypted=join(root,'protected.hwp');await writeFile(encrypted,hwp5('content',2));assert.equal((await run({mode:'read',input:encrypted})).failure.code,'ENCRYPTED');
});
test('HWPX password preserves input; correct password parse and wrong password rejected',async()=>{
 const p=join(upstream,'tests/fixtures/password/HWP5-password-123456.hwpx'),before=await readFile(p);
 const ok=await run({mode:'read',input:p,options:{password:'123456'}});assert.notEqual(ok.status,'failed',JSON.stringify(ok));
 assert.equal((await run({mode:'read',input:p,options:{password:'wrong'}})).status,'failed');assert.deepEqual(await readFile(p),before);
});
test('HWPML, DOCX, PPTX, XLSX and XLS reach the same read contract',async()=>{
 const xml=(body)=>'<?xml version="1.0" encoding="UTF-8"?>'+body;
 const hml=join(root,'sample.hml');await writeFile(hml,xml('<HWPML Version="2.0"><BODY><SECTION><P><TEXT><CHAR>한국어 HWPML 검증</CHAR></TEXT></P></SECTION></BODY></HWPML>'));
 const docx=await zipFile('sample.docx',{'word/document.xml':xml('<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>한국어 DOCX 검증</w:t></w:r></w:p></w:body></w:document>'),'[Content_Types].xml':xml('<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>')});
 const pptx=await zipFile('sample.pptx',{'ppt/presentation.xml':xml('<p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"/>'),'ppt/slides/slide1.xml':xml('<p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><p:cSld><p:spTree><p:sp><p:txBody><a:p><a:r><a:t>한국어 PPTX 검증</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:sld>')});
 const xlsx=await zipFile('sample.xlsx',{'xl/workbook.xml':xml('<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="검증" sheetId="1" r:id="rId1"/></sheets></workbook>'),'xl/_rels/workbook.xml.rels':xml('<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'),'xl/worksheets/sheet1.xml':xml('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>한국어 XLSX 검증</t></is></c></row></sheetData></worksheet>')});
 for(const [input,label]of [[hml,'HWPML'],[docx,'DOCX'],[pptx,'PPTX'],[xlsx,'XLSX'],[join(upstream,'tests/fixtures/xls/roster.xls'),'XLS']]){
  const r=await run({mode:'read',input});assert.notEqual(r.status,'failed',label+JSON.stringify(r));assert.ok(r.data.markdown.trim(),label);
 }
});
