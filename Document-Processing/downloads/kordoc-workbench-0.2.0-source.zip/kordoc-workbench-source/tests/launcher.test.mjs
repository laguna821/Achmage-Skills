import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,copyFile,link} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {spawnSync} from 'node:child_process';
test('Launcher returns structured missing-runtime and startup-dependency failures',async()=>{
 const root=await mkdtemp(resolve('outputs/launcher-contract-'));
 await mkdir(join(root,'scripts'),{recursive:true});
 await copyFile('skill/kordoc-workbench/scripts/launch.py',join(root,'scripts/launch.py'));
 const python=JSON.parse(spawnSync('python',['-c','import sys,json;print(json.dumps(sys.executable))'],{encoding:'utf8'}).stdout);
 const missing=spawnSync(python,[join(root,'scripts/launch.py')],{encoding:'utf8',input:'{}',env:{...process.env,PATH:'',USERPROFILE:root,HOME:root,KORDOC_NODE:''}});
 assert.equal(missing.status,1);assert.equal(JSON.parse(missing.stdout).failure.code,'RUNTIME_UNAVAILABLE');
 if(process.platform==='win32'){
  await mkdir(join(root,'runtime/win32-x64'),{recursive:true});
  await link(resolve('skill/kordoc-workbench/runtime/win32-x64/node.exe'),join(root,'runtime/win32-x64/node.exe'));
  await writeFile(join(root,'scripts/run.mjs'),"import 'missing-kordoc-test-dependency';");
  const dep=spawnSync('python',[join(root,'scripts/launch.py')],{encoding:'utf8',input:'{}'});
  assert.equal(dep.status,1);assert.equal(JSON.parse(dep.stdout).failure.code,'MISSING_DEPENDENCY');
  await writeFile(join(root,'scripts/run.mjs'),"console.log('{\"status\":\"success\"}');");
  const ok=spawnSync('python',[join(root,'scripts/launch.py')],{encoding:'utf8',input:'{}'});
  assert.equal(ok.status,0);assert.equal(JSON.parse(ok.stdout).status,'success');
 }
});
