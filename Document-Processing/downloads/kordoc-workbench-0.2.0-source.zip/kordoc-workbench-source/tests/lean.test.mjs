import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,cp,writeFile,readFile,mkdir,symlink} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {resolve,join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {requiredGroups} from '../skill/kordoc-workbench/scripts/extensions.mjs';
test('optional assets are selected by requested work',()=>{
 assert.deepEqual(requiredGroups({mode:'generate',markdown:'# 보고서'}),[]);
 assert.deepEqual(requiredGroups({mode:'template-analyze',input:'form.hwpx'}),[]);
 assert.deepEqual(requiredGroups({mode:'render',format:'pdf',input:'a.hwpx'}),['print']);
 assert.deepEqual(requiredGroups({mode:'ocr',input:'a.png'}),['ocr','raster']);
 assert(!requiredGroups({mode:'ocr',input:'a.png'}).includes('formula'));
});
test('isolated core: generate, parse, analyze, reuse, SVG, deterministic bytes, missing extension',async()=>{
 const temp=await mkdtemp(join(tmpdir(),'kordoc-lean-'));const skill=join(temp,'skill');
 const staged=resolve('staging/lean-0.2.0/kordoc-workbench'),manifest=JSON.parse(await readFile(join(staged,'PACKAGE-MANIFEST.json'),'utf8'));
 for(const f of [...manifest.files,{path:'PACKAGE-MANIFEST.json'}]){const to=join(skill,f.path);await mkdir(resolve(to,'..'),{recursive:true});await cp(join(staged,f.path),to);}
 const env={...process.env,NODE_PATH:'',KORDOC_OFFLINE:'1',KORDOC_WORKBENCH_CACHE:join(temp,'empty-cache')};
 const alias=join(temp,'registered-skill');await symlink(skill,alias,process.platform==='win32'?'junction':'dir');
 const viaAlias=spawnSync(process.execPath,[join(alias,'scripts/run.mjs')],{input:JSON.stringify({schemaVersion:1,mode:'capabilities'}),cwd:temp,env,encoding:'utf8'});assert.equal(JSON.parse(viaAlias.stdout).status,'success','Installed skill junction must execute the CLI');
 let seq=0;
 async function run(req){const input=join(temp,'request-'+(++seq)+'.json');await writeFile(input,JSON.stringify({schemaVersion:1,outputDir:join(temp,'out-'+seq),...req}));const p=spawnSync(process.execPath,[join(skill,'scripts/run.mjs'),input],{cwd:temp,env,encoding:'utf8'});assert(p.stdout,p.stderr);return JSON.parse(p.stdout);}
 const first=await run({mode:'generate',markdown:'# 보고서\n\n검증 본문입니다.\n\n| 항목 | 값 |\n| --- | --- |\n| 성과 | 완료 |'});assert.equal(first.status,'success',JSON.stringify(first));
 const doc=first.files[0].path;
 const second=await run({mode:'generate',markdown:'# 보고서\n\n검증 본문입니다.\n\n| 항목 | 값 |\n| --- | --- |\n| 성과 | 완료 |'});assert.equal(second.files[0].sha256,first.files[0].sha256);
 const read=await run({mode:'read',input:doc});assert.equal(read.status,'success',JSON.stringify(read));
 const pack=await run({mode:'template-analyze',input:doc});assert.equal(pack.status,'success',JSON.stringify(pack));
 const reuse=await run({mode:'template-apply',template:pack.files[0].path,markdown:'# 다른 보고서\n\n새로운 본문입니다.\n\n| 항목 | 값 |\n| --- | --- |\n| 성과 | 재사용 |'});assert.equal(reuse.status,'success',JSON.stringify(reuse));
 const svg=await run({mode:'render',format:'svg',input:doc});assert.equal(svg.status,'success',JSON.stringify(svg));
 const caps=await run({mode:'capabilities'});assert.equal(caps.status,'success');assert.equal(caps.data.extensions.ocr.ready,false);
 const pdf=await run({mode:'render',format:'pdf',input:doc});assert.equal(pdf.failure.code,'DEPENDENCY_UNAVAILABLE_OFFLINE');
 await mkdir(resolve('validation'),{recursive:true});await writeFile(resolve('validation/lean-isolation.json'),JSON.stringify({environment:'isolated temp directory, no node_modules, offline',temp,node:process.version,first,read,pack,reuse,svg,caps,pdf},null,2));
});
